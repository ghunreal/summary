﻿using System;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;

public class EditorUtil
{
	private static Dictionary<string, Dictionary<string, int>> sectionIndex = new Dictionary<string, Dictionary<string, int>>();

    public static void Clear()
    {
        sectionIndex.Clear();
    }

	public static int GetCSVIndex(string tableName, string sectionName)
	{
		if (string.IsNullOrEmpty(tableName) || string.IsNullOrEmpty(sectionName))
		{
			Debug.LogError("tableName or section is null");
			return -1;
		}
			
		Dictionary<string, int> temp;
		if(sectionIndex.TryGetValue(tableName, out temp))
		{
			return GetIndexImp(temp, sectionName);
		}
		else
		{
			// 加载表头
			if(LoadCSVHeaderIndex(tableName))
			{
				return GetCSVIndex(tableName, sectionName);
			}
			else
			{
				return -1;
			}
		}
	}

	private static int GetIndexImp(Dictionary<string, int> sections, string sectionName)
	{
		int result;
		if (sections.TryGetValue(sectionName, out result))
		{
			return result;
		}
		else
		{
			Debug.LogError(string.Format("Can't find {0}.", sectionName));
			return -1;
		}
	}

	public static bool LoadCSVHeaderIndex(string tableName)
	{
		if (tableName == string.Empty || sectionIndex.ContainsKey(tableName))
			return false;

		TextAsset csv = Resources.Load(string.Format("Data/{0}", tableName)) as TextAsset;

		if (csv == null)
		{
			Debug.LogError(string.Format("file Resources/Data/{0} can`t find", tableName));
			return false;
		}

		Dictionary<string, int> temp = new Dictionary<string, int>();
		CsvHeader.Header header = CsvHeader.Parse(csv.text);
		for (int i = 0; i < header.names.Length; i++)
		{
			temp.Add(header.names[i], i);
		}
		sectionIndex.Add(tableName, temp);
		return true;
	}
}
