﻿using UnityEngine;
using UnityEditor;
using System.Diagnostics;
using System.IO;

public static class LuaCompiler {
    private static string luajitPathIOS = "luajit-2.1.0";
	private static string luajitPathAnroid = "luajit-2.0.4";

    public static void Compile(string filename, BuildTarget target)
    {
        Process p = new Process();
        try
        {
            if (target == BuildTarget.Android)
            {
                p.StartInfo.FileName = luajitPathAnroid + "/src/luajit";
                p.StartInfo.WorkingDirectory = luajitPathAnroid + "/src/";
            }
			else if (target == BuildTarget.iOS)
            {
                p.StartInfo.FileName = luajitPathIOS + "/src/luajit";
                p.StartInfo.WorkingDirectory = luajitPathIOS + "/src/";
            }
			else
			{
				return;
			}

            p.StartInfo.UseShellExecute = false;
            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.RedirectStandardInput = false;
            p.StartInfo.RedirectStandardOutput = false;
            p.StartInfo.Arguments = string.Format("-b ../../{0} ../../{1}/{2}.bytes",
                filename, Path.GetDirectoryName(filename), Path.GetFileNameWithoutExtension(filename));

            p.Start();
            string error = p.StandardError.ReadToEnd();
            if (!string.IsNullOrEmpty(error))
                throw new System.Exception(error);
        }
        finally
        {
            p.WaitForExit();
            p.Close();
        }
    }
}
