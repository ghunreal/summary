﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

using SkillExporter = PlatoCppExporter<PlatoCppSkillType>;

//one phase (min unit)
[Serializable]
public class SkillPhaseItem
{
    public PLATO plato = new PLATO();
    public PLATO preview;

    public void Load(int skillID)
    {
        string filename = string.Format("{0}{1}{2}.txt", PLATO.PLATO_SAVE_PATH, "SkillScript", skillID);
        PlatoLoader loader = new PlatoLoader(plato);
        loader.Load(filename);
    }

    public void Load(string fileName)
    {
        PlatoLoader loader = new PlatoLoader(plato);
        loader.Load(fileName);
    }

    public void Save(int skillID)
    {
        string filename = string.Format("{0}{1}{2}.txt", PLATO.PLATO_SAVE_PATH, "SkillScript", skillID);
        PlatoSaver saver = new PlatoSaver(plato);
        saver.Save(filename);
    }

    public void Save(string fileName)
    {
        PlatoSaver saver = new PlatoSaver(plato);
        saver.Save(fileName);
    }

    public void Comment()
    {
        plato.Comment();
    }

    public void UpdateGUI(EditorWindow wnd, float offset)
    {
        if (preview != null)
            preview.DrawGUI(wnd, new Vector2(0, offset));
        else
            plato.DrawGUI(wnd, new Vector2(0, offset));
    }

    public void ExportLua(string filename)
    {
        plato.ExportLua(filename);
    }

    public static void ExportNode(PLATO plato, int skillID)
    {
        if (plato.graph == null)
            return;

        PLATO export = new PLATO(plato);
        PLATO.ExpandMacro(export);

        string filename = string.Format("{0}/SkillNode{1}.txt", PTGraph.EXPORT_LUA_PATH, skillID);
        PlatoWriter writer = new PlatoWriter(filename);
        writer.Line("require('plato/Skill')");
        writer.Line("require('plato/Get')");

        List<PlatoNode> inputNodes = new List<PlatoNode>();
        foreach (PlatoNode node in export.graph.GetAllNodes())
        {
            if (node.Sync)
                inputNodes.Add(node);
        }

        List<PlatoNode> outputNodes = new List<PlatoNode>();
        foreach (PlatoNode node in export.graph.GetAllNodes())
        {
            if (node.Category == "Get" && !PlatoExportUtil.IsGetNode(node))
                outputNodes.Add(node);
        }

        writer.Line("local SkillNode{0} = {{}}", skillID);
        writer.Line(null);

        writer.Line("SkillNode{0}.inputs = {{}}", skillID);
        foreach (PlatoNode node in inputNodes)
        {
            writer.Line("SkillNode{0}.inputs[{1}] = function(sync, actorid, skillid, nodeid)", skillID, node.ID);
            writer.PushIndent();
            writer.Line("local args = {{}}");
            writer.Line("args._IsSync = true");
            writer.Line("args._ActorID = actorid");
            writer.Line("args.Plato = {{}}");
            writer.Line("args.Plato.LauncherGO = PlatoUtil.GetActorByID(actorid)");
            writer.Line("args.Plato.PlatoID = skillid");
            writer.Line("args.NodeID = nodeid");
            ExportSyncArgs(writer, node);
            writer.Line("{0}.{1}.{2}(args)", node.Category, node.Title, node.FindPinByIndex(0, true).Title);
            writer.PopIndent();
            writer.Line("end");
        }
        writer.Line(null);

        writer.Line("SkillNode{0}.outputs = {{}}", skillID);
        foreach (PlatoNode node in outputNodes)
        {
            writer.Line("SkillNode{0}.outputs[{1}] = '{2}.{3}'", skillID, node.ID, node.Category, node.Title);
        }
        writer.Line(null);

        List<PlatoNode> confirms = export.graph.FindNodesByTitle("ConfirmPhase");
        if (confirms.Count > 0)
            writer.Line("SkillNode{0}.ConfirmPhase = {1}", skillID, confirms[0].ID);

        writer.Line("SkillNode{0}.effects = {{}}", skillID);
        foreach (PlatoNode node in export.graph.GetAllNodes().FindAll((x) => x.Title == "PlayEffect" || x.Title == "SpawnCollider"))
        {
            PlatoPin pin = node.FindPinByTitle("EffectID", true);
            int effect = (int)pin.Value;
            if (effect != 0)
                writer.Line("table.insert(SkillNode{0}.effects, {1})", skillID, pin.Value);
        }

        writer.Line("return SkillNode{0}", skillID);
        writer.Close();
    }

    static void ExportSyncArgs(PlatoWriter writer, PlatoNode node)
    {
        Dictionary<Type, int> indices = new Dictionary<Type, int>()
        {
            { typeof(string), 1 },
            { typeof(float), 1 },
            { typeof(int), 1 },
            { typeof(ulong), 1 },
            { typeof(bool), 1 },
        };

        foreach (PlatoPin pin in node.GetAllInPins())
        {
            if (PinTypeUtil.IsExec(pin) || !string.IsNullOrEmpty(pin.ParentPin))
                continue;

            if (pin is DropdownPin)
            {
                DropdownPin dropdown = pin as DropdownPin;
                writer.Line("local {0}s = {{", pin.Title);
                writer.PushIndent();
                for (int i = 0; i < dropdown.DropdownList.Count; ++i)
                {
                    writer.Line("[{0}] = '{1}',", i, dropdown.DropdownList[i]);
                }
                writer.PopIndent();
                writer.Line("}}");
                writer.Line("args.{0} = {0}s[sync.int32s[{1}]]", pin.Title, indices[typeof(int)]++);

                if (dropdown.PinDefines.Count > 0)
                {
                    // 神经病吧，不一样的节点拆分方式竟然不一样
                    if (node.Title == "SpawnCollider")
                        writer.Line("local params = string.split(sync.strings[{0}], ';')", indices[typeof(string)]++);
                    else
                        writer.Line("local params = string.split(sync.strings[{0}], ',')", indices[typeof(string)]++);
                    for (int i = 0; i < dropdown.PinDefines.Count; ++i)
                    {
                        writer.Line("if args.{0} == '{1}' then", pin.Title, dropdown.DropdownList[i]);
                        writer.PushIndent();
                        for (int j = 0; j < dropdown.PinDefines[i].Count; ++j)
                        {
                            var x = dropdown.PinDefines[i][j];
                            if (x.Value == typeof(bool))
                                writer.Line("args.{0} = params[{1}] == 'true' and true or false", x.Key, j + 1);
                            else if (x.Value == typeof(int) || x.Value == typeof(float))
                                writer.Line("args.{0} = tonumber(params[{1}])", x.Key, j + 1);
                            else
                                writer.Line("args.{0} = params[{1}]", x.Key, j + 1);
                        }
                        writer.PopIndent();
                        writer.Line("end");
                    }
                }
            }
            else
            {
                if (pin.Type.IsArray)
                    writer.Line("args.{0} = string.split(sync.strings[{1}], ';')", pin.Title, indices[typeof(string)]++);
                else
                    writer.Line("args.{0} = sync.{1}[{2}]", pin.Title, PinTypeUtil.GetCppVectorType(pin.Type).ToLower(), indices[pin.Type]++);
            }
        }

        foreach (PlatoPin pin in node.GetAllOutPins())
        {
            if (PinTypeUtil.IsExec(pin) || !string.IsNullOrEmpty(pin.ParentPin))
                continue;
            if (pin.Type.IsArray)
                writer.Line("args.{0} = string.split(sync.strings[{1}], ';')", pin.Title, indices[typeof(string)]++);
            else
                writer.Line("args.{0} = sync.{1}[{2}]", pin.Title, PinTypeUtil.GetCppVectorType(pin.Type).ToLower(), indices[pin.Type]++);
        }
    }

    public static void ExportCpp(PLATO plato, int skillID, SkilldataSetting setting)
    {
        if (plato.graph == null)
            return;

        PLATO export = new PLATO(plato);
        PLATO.ExpandMacro(export);

        SkillExporter exporter = new SkillExporter(export, skillID, setting);
        exporter.ExportCpp();
    }

    public static void ExportComponentToCpp(PLATO plato)
    {
        if (plato.graph == null)
            return;

        PLATO export = new PLATO(plato);
        PLATO.ExpandMacro(export);

        SkillExporter exporter = new SkillExporter(export, 0, null);
        exporter.ExportComponent();
    }

}

public class FrameEvent
{
    public float percent;
    public int intParam;
    public float floatParam;
    public string stringParam;
    public string functionName;
}