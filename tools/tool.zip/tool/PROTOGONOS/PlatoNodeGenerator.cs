﻿using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.IO;
using SLua;
using LuaInterface;


/// <summary>
/// 节点生成器
/// </summary>
public static class PlatoNodeGenerator
{
    /// <summary>所有节点原型</summary>
    public static Dictionary<string, Dictionary<string, PlatoNode>> AllNodes = new Dictionary<string, Dictionary<string, PlatoNode>>();
    /// <summary>LUA导出路径</summary>
    static readonly string LUA_PATH = "Assets/Scripts/Slua/Resources/plato/";
    /// <summary>自定义静态代码开始标记</summary>
    static readonly string STATIC_CODE_BEGIN = "------STATICBEGIN";
    /// <summary>自定义静态代码结束标记</summary>
    static readonly string STATIC_CODE_END = "------STATICEND";
    /// <summary>自定义代码开始标记</summary>
    static readonly string CODE_BEGIN = "------BEGIN";
    /// <summary>自定义代码结束标记</summary>
    static readonly string CODE_END = "------END";

    /// <summary>
    /// 导出lua
    /// </summary>
    [MenuItem("Custom/PLATO to Lua")]
    public static void GenerateLua()
    {
        Parse();

        // For each category (Action, Event, Math...)
        var category = AllNodes.GetEnumerator();
        while (category.MoveNext())
        {
            string filename = Path.Combine(LUA_PATH, category.Current.Key) + ".txt";
            string nodeName = null;

            // Save old codes
            Dictionary<string, List<string>> allCodes = new Dictionary<string, List<string>>();
            if (File.Exists(filename))
            {
                using (StreamReader reader = new StreamReader(filename, System.Text.Encoding.UTF8))
                {
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();
                        if (!string.IsNullOrEmpty(nodeName))
                        {
                            if (line.Contains(CODE_END))
                                nodeName = null;
                            else
                                allCodes[nodeName].Add(line);
                        }
                        else if (line.Contains(CODE_BEGIN))
                        {
                            nodeName = line.Split(' ')[1];
                            allCodes.Add(nodeName, new List<string>());
                        }
                    }
                }
            }

            // Write lua file
            using (StreamWriter writer = new StreamWriter(filename))
            {
                writer.WriteLine("{0} = {{}}", category.Current.Key);
                writer.WriteLine();

                var node = category.Current.Value.GetEnumerator();
                while (node.MoveNext())
                {
                    // Simple export, do not need generate lua class
                    if (!string.IsNullOrEmpty(node.Current.Value.FormatLua))
                        continue;
                    if (node.Current.Value.Title == "Reroute")
                        continue;

                    // new node call
                    node.Current.Value.GetAllInPins().FindAll((x) => PinTypeUtil.IsExec(x)).ForEach((x) =>
                    {
                        nodeName = string.Format("{0}.{1}.{2}", node.Current.Value.Category, node.Current.Value.Title, x.Title);
                        writer.WriteLine("---------------------------------------------------------------------");
                        writer.WriteLine("-- {0}", nodeName);
                        node.Current.Value.GetAllInPins().FindAll((p) => PinTypeUtil.IsValue(p)).ForEach((p) =>
                        { writer.WriteLine("-- input.{0}", p.Title); });
                        node.Current.Value.GetAllOutPins().FindAll((p) => PinTypeUtil.IsValue(p)).ForEach((p) =>
                        { writer.WriteLine("-- output.{0}", p.Title); });
                        node.Current.Value.GetAllOutPins().FindAll((p) => PinTypeUtil.IsExec(p) && (p as ExecPin).IsEvent).ForEach((p) =>
                        { writer.WriteLine("-- callback.{0}", p.Title); });
                        writer.WriteLine("---------------------------------------------------------------------");
                        writer.WriteLine("{0}.{1} = {0}.{1} or {{}}", category.Current.Key, node.Current.Key);
                        writer.WriteLine("{0} = function(args)", nodeName);
                        writer.WriteLine("{0} {1} CALL------", CODE_BEGIN, nodeName);
                        List<string> codes;
                        if (allCodes.TryGetValue(nodeName, out codes))
                        {
                            foreach (string code in codes)
                            {
                                writer.WriteLine(code);
                            }
                        }
                        writer.WriteLine("{0} {1} CALL------", CODE_END, nodeName);
                        writer.WriteLine("end");
                        writer.WriteLine();
                    });
                }
            }
        }
    }

    /// <summary>
    /// 解析
    /// </summary>
    public static void Parse()
    {
        AllNodes.Clear();

        string[] assets = AssetDatabase.FindAssets("t:TextAsset", new string[] { "Assets/Editor Default Resources/PLATO/Defines" });
        foreach (string guid in assets)
        {
            string filename = AssetDatabase.GUIDToAssetPath(guid);
            Dictionary<string, PlatoNode> nodes = new Dictionary<string, PlatoNode>();
            Parse(filename, nodes);
            AllNodes.Add(Path.GetFileNameWithoutExtension(filename), nodes);
        }

        // Editor nodes
        Dictionary<string, PlatoNode> editorNodes = new Dictionary<string,PlatoNode>();
        var assembly = Assembly.Load("Assembly-CSharp-Editor");
        foreach (var type in assembly.GetTypes())
        {
            if (type.BaseType == typeof(EditorNode))
            {
                string name = type.Name.Substring(0, type.Name.Length - 4);
                editorNodes.Add(name, type.GetConstructor(Type.EmptyTypes).Invoke(null) as PlatoNode);
            }
        }
        AllNodes.Add("Editor", editorNodes);
    }

    /// <summary>
    /// 解析
    /// </summary>
    /// <param name="filename"></param>
    /// <param name="nodes"></param>
    static void Parse(string filename, Dictionary<string, PlatoNode> nodes)
    {
        TextAsset asset = AssetDatabase.LoadAssetAtPath<TextAsset>(filename);
        if (asset == null)
        {
            Debug.LogError(string.Format("Can not found file [{0}]", filename));
            return;
        }

        // 启动一个临时lua虚拟机来解析
        IntPtr L = LuaDLL.luaL_newstate();
        LuaDLL.luaL_openlibs(L);

        object table;
        if (LuaUtil.LoadLua(L, asset.bytes, filename, out table))
        {
            Color nodeColor = Color.white;
            LuaUtil.TravelTable(L, table as LuaTable, (key, value) =>
            {
                if (key == "Color")
                    ColorUtility.TryParseHtmlString((string)value, out nodeColor);
                else if (key == "Nodes")
                    ParseNodes(L, value as LuaTable, nodes);
            });

            // 后处理，为每个该类别下的节点设置类别和颜色
            foreach (PlatoNode node in nodes.Values)
            {
                node.Category = Path.GetFileNameWithoutExtension(filename);
                node.SetColor(nodeColor);
            }
        }

        LuaDLL.lua_close(L);
        L = IntPtr.Zero;
    }

    /// <summary>
    /// 解析节点表
    /// </summary>
    /// <param name="L"></param>
    /// <param name="table"></param>
    /// <param name="nodes"></param>
    static void ParseNodes(IntPtr L, LuaTable table, Dictionary<string, PlatoNode> nodes)
    {
        LuaUtil.TravelTable(L, table, (key, value) =>
        {
            PlatoNode node = ParseNode(L, value as LuaTable);
            nodes.Add(node.Title, node);
        });
    }

    /// <summary>
    /// 解析节点
    /// </summary>
    /// <param name="L"></param>
    /// <param name="table"></param>
    /// <returns></returns>
    static PlatoNode ParseNode(IntPtr L, LuaTable table)
    {
        PlatoNode node = new PlatoNode();
        LuaUtil.TravelTable(L, table, (key, value) =>
        {
            if (key == "Title")
                node.Title = (string)value;
            else if (key == "In")
                ParsePins(L, node, value as LuaTable, true);
            else if (key == "Out")
                ParsePins(L, node, value as LuaTable, false);
            else if (key == "Format")
                node.FormatLua = (string)value;
            else if (key == "FormatCpp")
                node.FormatCpp = (string)value;
            else if (key == "Key")
                node.Key = (string)value;
            else if (key == "ExportCall")
                node.ExportCall = (bool)value;
            else if (key == "Sync")
                node.Sync = (bool)value;
        });
        return node;
    }

    /// <summary>
    /// 解析输入引脚
    /// </summary>
    /// <param name="L"></param>
    /// <param name="node"></param>
    /// <param name="table"></param>
    /// <param name="isInput"></param>
    static void ParsePins(IntPtr L, PlatoNode node, LuaTable table, bool isInput)
    {
        LuaUtil.TravelTable(L, table, (key, value) =>
        {
			PlatoPin pin = ParsePin(L, value as LuaTable);
            pin.IsInput = isInput;
            node.AddPin(pin);
        });
    }

    /// <summary>
    /// 解析引脚数据
    /// </summary>
    /// <param name="L"></param>
    /// <param name="table"></param>
    /// <returns>名字和类型的Pair对</returns>
    static PlatoPin ParsePin(IntPtr L, LuaTable table)
    {
        PlatoPin pin = null;
        LuaUtil.TravelTable(L, table, (key, value) =>
        {
            if (key == "Type")
                pin = CreatePin(LuaObject.FindType(value as string));
		});
        LuaUtil.TravelTable(L, table, (key, value) =>
        {
            pin.Parse(key, value);
        });
        return pin;
    }
    
    /// <summary>
    /// 查找节点
    /// </summary>
    /// <param name="title">节点名</param>
    /// <returns></returns>
    public static PlatoNode FindPrototypeByTitle(string title)
    {
        var category = AllNodes.GetEnumerator();
        while (category.MoveNext())
        {
            var node = category.Current.Value.GetEnumerator();
            while (node.MoveNext())
            {
                if (node.Current.Value.Title == title)
                    return node.Current.Value;
            }
        }
        return null;
    }

    /// <summary>
    /// 查找某类别下的所有原型
    /// </summary>
    /// <param name="category">类别名</param>
    /// <returns></returns>
    public static List<PlatoNode> FindPrototypesByCategory(string category)
    {
        List<PlatoNode> result = new List<PlatoNode>();

        Dictionary<string, PlatoNode> prototypes;
        if (AllNodes.TryGetValue(category, out prototypes))
        {
            foreach (var prototype in prototypes.Values)
            {
                result.Add(prototype);
            }
        }
        return result;
    }

    /// <summary>
    /// 创建回调信息
    /// </summary>
    class CreateEntry
    {
        public PlatoNode node;
        public PLATO plato;
        public CreateEntry(PlatoNode node, PLATO plato)
        {
            this.node = node;
            this.plato = plato;
        }
    }

    /// <summary>
    /// 生成右键菜单
    /// </summary>
    /// <param name="menu"></param>
    public static void GenerateMenu(GenericMenu menu, PLATO plato)
    {
        var category = AllNodes.GetEnumerator();
        while (category.MoveNext())
        {
            if (category.Current.Key == "Editor")
                continue;

            string prefix = category.Current.Key + "/";
            var node = category.Current.Value.GetEnumerator();
            while (node.MoveNext())
            {
                menu.AddItem(new GUIContent(prefix + node.Current.Key),
                    false, CreateNode, new CreateEntry(node.Current.Value, plato));
            }
        }
    }

    /// <summary>
    /// 菜单回调，创建原型的克隆
    /// </summary>
    /// <param name="userData"></param>
    static void CreateNode(object userData)
    {
        CreateEntry entry = userData as CreateEntry;
        PlatoNode node = entry.node.Clone(entry.plato);
        PLATO.AddNode(node, entry.plato);
    }

    static Dictionary<Type, Type> AllPins = new Dictionary<Type, Type>()
    {
        { typeof(bool), typeof(BoolPin) },
        { typeof(bool[]), typeof(BoolArrayPin) },
        { typeof(int), typeof(IntPin) },
        { typeof(int[]), typeof(IntArrayPin) },
        { typeof(ulong), typeof(UInt64Pin) },
        { typeof(ulong[]), typeof(UInt64ArrayPin) },
        { typeof(float), typeof(FloatPin) },
        { typeof(float[]), typeof(FloatArrayPin) },
        { typeof(string), typeof(StringPin) },
        { typeof(Dictionary<Int32, Int32>), typeof(MapPin<Int32, Int32>) },
        { typeof(Dictionary<Int32, float>), typeof(MapPin<Int32, float>) },
        { typeof(Dictionary<UInt64, UInt64>), typeof(UInt64MapPin) },
        { typeof(GameObject), typeof(ObjectPin) },
        { typeof(Button), typeof(ButtonPin) },
        { typeof(Dropdown), typeof(DropdownPin) },
    };
    public static PlatoPin CreatePin(Type type)
    {
        Type prototype;
        if (type == null)
            prototype = typeof(ExecPin);
        else if (!AllPins.TryGetValue(type, out prototype))
            throw new Exception("Unknown pin type: " + type.ToString());
        PlatoPin pin = prototype.GetConstructor(Type.EmptyTypes).Invoke(null) as PlatoPin;
        pin.Type = type;
        PinTypeUtil.SetDefault(pin);
        return pin;
    }

    private static void WriteRequire(StreamWriter writer, List<string> list)
    {
        if (list != null)
        {
            foreach (var line in list)
            {
                writer.WriteLine(line);
            }
            writer.WriteLine();
        }
    }
}
