﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using SLua;
using LuaInterface;

public class PlatoExportUtil
{
	/// <summary>
	/// 重新导出所有技能脚本
	/// </summary>
	[MenuItem("Export/Export All Skills")]
	public static void ExportAllSkill()
	{
		PlatoNodeGenerator.GenerateLua();

        // Client
		string[] filenames = Directory.GetFiles (PLATO.PLATO_SAVE_PATH, "*.txt", SearchOption.TopDirectoryOnly);
		foreach (string filename in filenames)
		{
			if (!filename.Contains ("SkillScript"))
				continue;

			try
			{
				PLATO plato = new PLATO ();
                PlatoLoader loader = new PlatoLoader(plato);
                loader.Load(filename);
				plato.ExportLua(Path.Combine(PTGraph.EXPORT_LUA_PATH, Path.GetFileName(filename)));
			}
			catch (Exception ex) {
				Debug.LogErrorFormat ("{0}: {1}", filename, ex.Message);
			}
		}

        // Server
        IntPtr L = LuaDLL.luaL_newstate();
        LuaDLL.luaL_openlibs(L);

        List<SkilldataSetting> settings = new List<SkilldataSetting>();

        filenames = Directory.GetFiles(PTGraph.EXPORT_LUA_PATH, "*.txt", SearchOption.TopDirectoryOnly);
        foreach (string filename in filenames)
        {
            if (filename.Contains("SkillData") == false)
                continue;

            TextAsset asset = AssetDatabase.LoadAssetAtPath<TextAsset>(filename);

            object table;
            if (LuaUtil.LoadLua(L, asset.bytes, filename, out table) && table != null)
            {
                (table as LuaTable).l = L;
                var iter = (table as LuaTable).GetEnumerator();
                while (iter.MoveNext())
                {
                    LuaTable data = iter.Current.value as LuaTable;
                    if (data == null)
                        continue;

                    SkilldataSetting setting = new SkilldataSetting();
                    LuaUtil.TravelTable(L, data, (string key, object value) =>
                    {
                        switch (key)
                        {
                            case "skillID": setting.skillID = Convert.ToInt32(value); break;
                            case "skillName": setting.skillName = (string)value; break;
                            //case "cdType": setting.cdType = Convert.ToInt32(value); break;
                            //case "cdValue": setting.cdValue = Convert.ToInt32(value); break;
                            case "castType": setting.castType = (PTCastType)Convert.ToInt32(value); break;
                            case "rangeEffectID": setting.rangeEffectID = Convert.ToInt32(value); break;
                            case "rangeRadius": setting.rangeRadius = Convert.ToInt32(value); break;
                            case "indicatorEffectID": setting.indicatorEffectID = Convert.ToInt32(value); break;
                            case "indicatorType": setting.indicatorType = (PTIndicatorType)Convert.ToInt32(value); break;
                            case "indicatorRadius": setting.indicatorRadius = Convert.ToInt32(value); break;
                            case "indicatorAngle": setting.indicatorAngle = Convert.ToInt32(value); break;
                            case "indicatorLength": setting.indicatorLength = Convert.ToInt32(value); break;
                            case "indicatorWidth": setting.indicatorWidth = Convert.ToInt32(value); break;
                            case "indicatorFollowType": setting.indicatorFollowType = (PTIndicatorFollowType)Convert.ToInt32(value); break;
                            case "needCheckCollider": setting.needCheckCollider = Convert.ToBoolean(value); break;
                            case "isSecondPhase": setting.isSecondPhase = Convert.ToBoolean(value); break;
                            case "secondTrigger": setting.secondTrigger = (SecondTrigger)Convert.ToInt32(value); break;
                            case "secondEvent": setting.secondEvent = (SecondEvent)Convert.ToInt32(value); break;
                        }
                    });
                    settings.Add(setting);
                }
                iter.Dispose();
            }
        }

        LuaDLL.lua_close(L);
        L = IntPtr.Zero;

        foreach (SkilldataSetting setting in settings)
        {
            PLATO plato = new PLATO();
            PlatoLoader loader = new PlatoLoader(plato);
            loader.Load(string.Format("{0}SkillScript{1}.txt", PLATO.PLATO_SAVE_PATH, setting.skillID));
            SkillPhaseItem.ExportNode(plato, setting.skillID);
            SkillPhaseItem.ExportCpp(plato, setting.skillID, setting);
            SkillPhaseItem.ExportComponentToCpp(plato);
        }
	}

	/// <summary>
	/// 重新导出所有武器脚本
	/// </summary>
	[MenuItem("Export/Export All Weapons")]
	public static void ExportAllWeapons()
	{
		PlatoNodeGenerator.GenerateLua();

        // Client
		string[] filenames = Directory.GetFiles (PLATO.PLATO_WEAPON_SAVE_PATH, "*.txt", SearchOption.TopDirectoryOnly);
		foreach (string filename in filenames)
		{
			if (!filename.Contains ("WeaponScript"))
				continue;

			try
			{
				PLATO plato = new PLATO ();
                PlatoLoader loader = new PlatoLoader(plato);
                loader.Load(filename);
				plato.ExportLua(Path.Combine(PTGraph.EXPORT_WEAPON_LUA_PATH, Path.GetFileName(filename)));
			}
			catch (Exception ex) {
				Debug.LogErrorFormat ("{0}: {1}", filename, ex.Message);
			}
		}

	}

	public static void ExportCppParam(List<PlatoPin> pins, PlatoWriter writer)
	{
        for (int i = 0; i < pins.Count; ++i)
        {
            PlatoPin pin = pins[i];
            if (IsSkip(pin))
                continue;

            pin.ExportCppParam(writer);
        }
	}
	public static void ExportCppField(List<PlatoPin> pins, PlatoWriter writer)
	{
        for (int i = 0; i < pins.Count; ++i)
        {
            PlatoPin pin = pins[i];
            if (IsSkip(pin))
                continue;

            pin.ExportCppField(writer);
        }
	}

    private static bool IsSkip(PlatoPin pin)
    {
        if (PinTypeUtil.IsExec(pin))
            return true;
        if (!string.IsNullOrEmpty(pin.ParentPin))
            return true;
        return false;
    }

    public static void ExportLinkPins(List<PlatoPin> linkPins, PlatoWriter writer)
    {
        foreach (PlatoPin p in linkPins)
        {
            PlatoPin dst = p;
            PlatoPin src = p.Prevs[0];

            string srcStr;
            if (string.IsNullOrEmpty(src.ParentPin))
                srcStr = string.Format("node{0}->get{1}()", src.ParentNode.ID, src.Title);
            else
                srcStr = string.Format("node{0}->{1}({2})", src.ParentNode.ID, GetSetParams(src, "get"), src.ChildIndex);

            //TODO(kai.zou): 需要重构
            if (dst.ParentNode.Title == "ReviseMapI32" && dst.ParentPin == "Add" && dst.ChildIndex % 2 == 1)
            {
                PlatoPin typePin = dst.ParentNode.GetSameParentPins(dst.ParentPin)[dst.ChildIndex - 1];
                writer.Line("    if (node{0} != nullptr) node{1}->reviseValue({2}, {3});", src.ParentNode.ID, dst.ParentNode.ID, typePin.Value, srcStr);
            }
            else
            {
                string dstStr;
                if (string.IsNullOrEmpty(dst.ParentPin))
                    dstStr = string.Format("node{0}->set{1}(", dst.ParentNode.ID, dst.Title);
                else
                    dstStr = string.Format("node{0}->{1}({2}, ", dst.ParentNode.ID, GetSetParams(dst, "set"), dst.ChildIndex);

                writer.Line("    if (node{0} != nullptr) {1}{2});", src.ParentNode.ID, dstStr, srcStr);
            }
        }
    }

    public static void ExportVarPin(PlatoPin pin, int nodeId, int id, PlatoWriter writer)
    {
        PlatoPin prev = pin.Prevs[0];

        PlatoPin pp = prev.ParentNode.FindPinByTitle("Name", true);
        if(pp != null)
        {
            string prevTitle = pp.Value as string;

            if (string.IsNullOrEmpty(pin.ParentPin))
                writer.Line("        node{0}->set{1}(variables->getVariable<{2}>(Variable_{3}_{4}));", nodeId, pin.Title, PinTypeUtil.GetCppType(prev.Type), id, prevTitle);
            else
            {
                if (pin.ParentNode.Title == "ReviseMapI32")
                {
                    PlatoPin typePin = pin.ParentNode.GetSameParentPins(pin.ParentPin)[pin.ChildIndex - 1];
                    writer.Line("        node{0}->{1}({2}, variables->getVariable<{3}>(Variable_{4}_{5}));", nodeId, "reviseValue", typePin.Value, PinTypeUtil.GetCppType(prev.Type), id, prevTitle);
                }
                else
                {
                    writer.Line("        node{0}->{1}({2}, variables->getVariable<{3}>(Variable_{4}_{5}));", nodeId, GetSetParams(pin, "set"), pin.ChildIndex, PinTypeUtil.GetCppType(prev.Type), id, prevTitle);
                }
            }                
        }

    }

    private static string GetSetParams(PlatoPin pin, string prefix)
    {
        PlatoPin parentPin = pin.ParentNode.FindPinByTitle(pin.ParentPin, true);
        if (parentPin is ButtonPin)
        {
            return string.Format("{1}{0}", (parentPin as ButtonPin).CallbackNodeName, prefix);
        }
        else if (parentPin is DropdownPin)
        {
            Type baseType;
            if (DropdownPin.IsSameType(parentPin as DropdownPin, out baseType))
                return string.Format("{1}{0}Params", parentPin.Title, prefix);
            else
                return string.Format("getVars().{1}Variable<{0}>", PinTypeUtil.GetCppType(pin.Type), prefix);
        }
        else
        {
            throw new Exception(string.Format("Invalid ParentPin: {0}.{1}", pin.ParentNode.Title, pin.Title));
        }
    }


    public static bool IsEmptyString(string str)
    {
        if (str == null || str == "" || str == LuaUtil.EmptyBase64)
            return true;
        return false;
    }

    public static bool IsGetNode(PlatoNode node)
    {
        if (node.Category != "Get")
        {
            return false;
        }
        else
        {
            if (node.Title.Contains("Location"))
                return false;
            else if (node.Title.Contains("Rotation"))
                return false;
            else if (node.Title.Contains("Input"))
                return false;
            else if (node.Title.Contains("State"))
                return false;
            else if (node.Title == "GetProjOwnerAttr")
                return false;
        }
        return true;
    }

    /// <summary>
    /// 简单格式导出
    /// </summary>
    /// <returns></returns>
    public static string ExportFormat(PlatoNode node, string format)
    {
        // 解析形如print({Message})的格式，遇到{}对的时候
        // 将Message替换为ExportInPinByTitle("Message")
        try
        {
            List<char> code = new List<char>();
            int i = 0;
            while (i < format.Length)
            {
                char c = format[i];
                if (c == '{')
                {
                    // 一直遍历到}为止，将{}中间的内容作为pinName
                    List<char> pinNameList = new List<char>();
                    while (++i < format.Length)
                    {
                        c = format[i];
                        if (c == '}')
                        {
                            ++i;
                            break;
                        }
                        else
                        {
                            pinNameList.Add(c);
                        }
                    }

                    string pinName = new string(pinNameList.ToArray());
                    // 特殊标记，节点ID
                    if (pinName == "NODE_ID")
                    {
                        code.AddRange(node.ID.ToString());
                    }
                    // 特殊标记，所有动态输入引脚
                    else if (pinName == "DYNAMIC_INPUTS")
                    {
                        List<string> inputs = new List<string>();
                        foreach (PlatoPin pin in node.GetAllInPins().FindAll((x) => x.IsDynamic))
                        {
                            inputs.Add(PlatoExportUtil.ExportInPinByTitleLua(node, pin.Title));
                        }
                        if (inputs.Count > 0)
                            code.AddRange(string.Join(", ", inputs.ToArray()));
                        else
                            code.AddRange("nil");
                    }
                    else
                    {
                        // 先从输入引脚开始查找
                        PlatoPin pin = node.FindPinByTitle(pinName, true);
                        if (pin == null)
                        {
                            // 没有找到就查找输出引脚
                            pin = node.FindPinByTitle(pinName, false);
                            if (pin != null)
                            {
                                code.AddRange(pin.ExportToLua());
                            }
                            else
                                throw new System.Exception();
                        }
                        else
                        {
                            code.AddRange(PlatoExportUtil.ExportInPinByTitleLua(node, pinName));
                        }
                    }
                }
                else
                {
                    code.Add(c);
                    ++i;
                }
            }
            return new string(code.ToArray());
        }
        catch
        {
            Debug.LogError(string.Format("Format error: [{0}.{1}] '{2}'", node.Category, node.Title, format));
        }
        return string.Empty;
    }

    /// <summary>
    /// 导出输入引脚
    /// </summary>
    /// <param name="title"></param>
    /// <returns></returns>
    public static string ExportInPinByTitleLua(PlatoNode node, string title)
    {
        PlatoPin pin = node.FindPinByTitle(title, true);
        // 如果有前驱，使用前驱的输出
        if (pin.Prevs.Count == 1)
        {
            PlatoPin prev = pin.Prevs[0];
            while (prev.ParentNode.Title == "Reroute")
            {
                prev = prev.Prevs[0];
            }
            return ExportOutPinByTitleLua(prev.ParentNode, prev.Title);
        }
        else
        {
            return pin.ExportToLua();
        }
    }

    /// <summary>
    /// 导出输出引脚
    /// </summary>
    /// <param name="title"></param>
    /// <returns></returns>
    public static string ExportOutPinByTitleLua(PlatoNode node, string title)
    {
        PlatoPin pin = node.FindPinByTitle(title, false);
        if (!string.IsNullOrEmpty(pin.PinFormat))
            return ExportFormat(node, pin.PinFormat);
        else
            return string.Format("self.{0}_{1}_{2}", node.Title, node.ID, title);
    }
}
