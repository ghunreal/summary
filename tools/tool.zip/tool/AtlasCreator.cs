﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class AtlasCreator
{
    private static string atlasFolder = "Assets/Atlas";
    private static string prefabFolder = "Assets/Resources/UI";

    public static void CreateAtlasPrefab()
    {
        if (Directory.Exists(atlasFolder))
            Directory.Delete(atlasFolder, true);
        Directory.CreateDirectory(atlasFolder);

        string[] dirs = Directory.GetDirectories(prefabFolder, "*", SearchOption.AllDirectories);
        foreach (string dir in dirs)
        {
            string folder = dir.Replace(prefabFolder, atlasFolder);
            Directory.CreateDirectory(folder);
        }
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        AssetDatabase.SaveAssets();

        foreach (string dir in dirs)
        {
            string folder = dir.Replace(prefabFolder, atlasFolder);
            MoveSprites(dir, folder);
            CreatePrefab(folder, dir);
        }
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        AssetDatabase.SaveAssets();
    }

    public static void Revert()
    {
        string[] dirs = Directory.GetDirectories(prefabFolder, "*", SearchOption.AllDirectories);
        foreach (string dir in dirs)
        {
            string[] files = Directory.GetFiles(dir);
            foreach (string file in files)
            {
                if (string.IsNullOrEmpty(file) || Path.GetExtension(file) == ".meta")
                    continue;
                AssetDatabase.DeleteAsset(file);
            }
        }
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        AssetDatabase.SaveAssets();

        dirs = Directory.GetDirectories(atlasFolder, "*", SearchOption.AllDirectories);
        foreach (string dir in dirs)
        {
            string folder = dir.Replace(atlasFolder, prefabFolder);
            MoveSprites(dir, folder);
        }
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        AssetDatabase.SaveAssets();

        if (Directory.Exists(atlasFolder))
            Directory.Delete(atlasFolder, true);
    }

    static void MoveSprites(string srcFolder, string dstFolder)
    {
        string[] files = Directory.GetFiles(srcFolder);
        foreach (string file in files)
        {
            if (Path.GetExtension(file) == ".meta")
                continue;
            string filename = Path.GetFileName(file);
            AssetDatabase.MoveAsset(Path.Combine(srcFolder, filename), Path.Combine(dstFolder, filename));
        }
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        AssetDatabase.SaveAssets();
    }

    static void CreatePrefab(string srcFolder, string dstFolder)
    {
        List<SpriteAtlas.Entry> entries = new List<SpriteAtlas.Entry>();
        string[] files = Directory.GetFiles(srcFolder);
        foreach (string file in files)
        {
            if (string.IsNullOrEmpty(file) || Path.GetExtension(file) == ".meta")
                continue;

            Sprite sprite = AssetDatabase.LoadAssetAtPath<Sprite>(file);
            entries.Add(new SpriteAtlas.Entry() { name = sprite.name, sprite = sprite });
        }

        SpriteAtlas atlas = ScriptableObject.CreateInstance<SpriteAtlas>();
        atlas.entries = entries.ToArray();

        string assetPath = Path.Combine(dstFolder, "atlas") + ".asset";
        AssetDatabase.CreateAsset(atlas, assetPath.Replace('\\', '/'));
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
    }
}
