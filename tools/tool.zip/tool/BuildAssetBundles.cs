﻿using UnityEngine;
using UnityEditor;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;


/// <summary>
/// 生成Asset Bundles
/// </summary>
public class BuildAssetBundles : EditorWindow
{
    /// <summary>
    /// 选中的asset以及folder
    /// </summary>
    private class AssetEntry
    {
        public string path;     // 路径
        public bool selected;   // 是否选中
    }

    /// <summary>滚动条坐标</summary>
    private Vector2 scrollPos;

    private static BuildTarget target = BuildTarget.Android;
    private static string outputPath = ".";
    private static string version = "1.0.1";

    /// <summary>需要生成asset bundle包</summary>
    private static List<AssetBundleBuild> builds = new List<AssetBundleBuild>();
    private static string[] assetFolders = new string[] { "Assets/Resources", "Assets/Content" };
    private static List<AssetEntry> allFolders = new List<AssetEntry>();
    private static List<AssetEntry> allFiles = new List<AssetEntry>();
    private static string[] buildFolders;
    private static string[] buildFiles;
    private static List<string> skipAssets = new List<string>();
    
    private static string luaFolder = "Assets/Scripts/Slua/Resources";
    private static string dataFolder = "Assets/Resources/Data";
    private static string dependencyFolder = "Assets/Dependencies/";

    [MenuItem("Build/Build AssetsBundles")]
    public static void ShowWindow()
    {
        EditorWindow.GetWindow<BuildAssetBundles>();
    }

    static void ListAll()
    {
        allFiles.Clear();
        allFolders.Clear();

        foreach (string file in Directory.GetFiles("Assets", "*.unity", SearchOption.AllDirectories))
        {
            allFiles.Add(new AssetEntry() { path = file.Replace('\\', '/') });
        }

        allFolders.Add(new AssetEntry() { path = luaFolder });
        foreach (string assetFolder in assetFolders)
        {
            foreach (string folder in Directory.GetDirectories(assetFolder, "*", SearchOption.AllDirectories))
            {
                allFolders.Add(new AssetEntry() { path = folder.Replace('\\', '/') });
            }
            allFolders.Add(new AssetEntry() { path = assetFolder.Replace('\\', '/') });
        }
    }

    static void SelectAllFiles()
    {
        foreach (AssetEntry entry in allFiles)
        {
            entry.selected = true;
        }
    }

    static void UnselectAllFiles()
    {
        foreach (AssetEntry entry in allFiles)
        {
            entry.selected = false;
        }
    }

    static void SelectAllFolders()
    {
        foreach (AssetEntry entry in allFolders)
        {
            entry.selected = true;
        }
    }

    static void UnselectAllFolders()
    {
        foreach (AssetEntry entry in allFolders)
        {
            entry.selected = false;
        }
    }

    static void GetBuildFilesAndFolders()
    {
        // 需要生成的文件
        List<AssetEntry> files = allFiles.FindAll((entry) => { return entry.selected; });
        buildFiles = new string[files.Count];
        for (int i = 0; i < files.Count; ++i)
        {
            buildFiles[i] = files[i].path;
        }

        // 需要生成的文件夹
        List<AssetEntry> folders = allFolders.FindAll((entry) => { return entry.selected; });
        buildFolders = new string[folders.Count];
        for (int i = 0; i < folders.Count; ++i)
        {
            buildFolders[i] = folders[i].path;
        }
    }

    void OnEnable()
    {
        ListAll();
    }

    /// <summary>
    /// GUI显示
    /// </summary>
    void OnGUI()
    {
        // 编译平台
        target = (BuildTarget)EditorGUILayout.EnumPopup("Build target", target);

        // 输出路径
        GUILayout.Label("Output path", EditorStyles.boldLabel);
        if (GUILayout.Button(outputPath == string.Empty ? "Output path" : outputPath, EditorStyles.miniButtonMid))
        {
            outputPath = EditorUtility.SaveFolderPanel("Save folder", "Assets/StreamingAssets", "");
        }

        // 版本号
        version = EditorGUILayout.TextField("Version", version);

        // 列出所有可以被生成的文件
        GUILayout.Label("Files", EditorStyles.boldLabel);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Select All"))
        {
            SelectAllFiles();
        }
        if (GUILayout.Button("Unselect All"))
        {
            UnselectAllFiles();
        }
        GUILayout.EndHorizontal();
        foreach (var file in allFiles)
        {
            file.selected = GUILayout.Toggle(file.selected, file.path);
        }

        // 列出所有可以被生成的文件夹
        GUILayout.Label("Folders", EditorStyles.boldLabel);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Select All"))
        {
            SelectAllFolders();
            
        }
        if (GUILayout.Button("Unselect All"))
        {
            UnselectAllFolders();
        }
        GUILayout.EndHorizontal();
        scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.Height(200));
        foreach (var folder in allFolders)
        {
            folder.selected = GUILayout.Toggle(folder.selected, folder.path);
        }
        GUILayout.EndScrollView();

        // 生成按钮
        if (GUILayout.Button("Build", EditorStyles.miniButtonMid))
        {
            GetBuildFilesAndFolders();
            BuildAll();
        }
    }

    /// <summary>
    /// 生成
    /// </summary>
    public static void BuildAll()
    {
        builds.Clear();

        ParseCommandArgs();

        // 没有需要生成的内容，退出
		if (buildFiles.Length == 0 && buildFolders.Length == 0)
			return;

        EditorUserBuildSettings.SwitchActiveBuildTarget(target);

        // 创建依赖文件目录
        if (!Directory.Exists(dependencyFolder))
            Directory.CreateDirectory(dependencyFolder);
        AssetDatabase.Refresh();

        // 重建依赖关系
        RebuildDatabase();

        // 创建输出目录
        if (!Directory.Exists(outputPath))
            Directory.CreateDirectory(outputPath);

        // 创建临时目录，用来存放未压缩的asset bundle包
        string tempFolder = Application.temporaryCachePath;
        if (Directory.Exists(tempFolder))
            Directory.Delete(tempFolder, true);
        Directory.CreateDirectory(tempFolder);

        skipAssets.Clear();
#if USE_RES_ATLAS
        AtlasCreator.CreateAtlasPrefab();
#endif // USE_RES_ATLAS
        BuildScenes();
        BuildData();
		BuildLua();
        BuildResources();

        // 生成asset bundle包
        BuildPipeline.BuildAssetBundles(tempFolder, builds.ToArray(),
            BuildAssetBundleOptions.DeterministicAssetBundle | BuildAssetBundleOptions.ChunkBasedCompression,
            target);

        // 复制到输出目录
        foreach (string file in Directory.GetFiles(tempFolder))
        {
            if (Path.GetExtension(file) == ".manifest")
                continue;
            if (Path.GetFileName(file) == Path.GetFileName(tempFolder))
                continue;
            File.Copy(file, Path.Combine(outputPath, Path.GetFileName(file)));
        }

        // 清理
		Clear();

		AssetDatabase.Refresh();
    }

    /// <summary>
    /// 清理
    /// </summary>
    static void Clear()
    {
        //删除临时目录文件
        Directory.Delete(Application.temporaryCachePath, true);

        ClearLua();
        ClearData();
#if USE_RES_ATLAS
        AtlasCreator.Revert();
#endif // USE_RES_ATLAS
    }

    /// <summary>
    /// LZMA压缩
    /// </summary>
    /// <param name="inFile">输入文件名</param>
    /// <param name="outFile">输出文件名</param>
    static void CompresssFileLZMA(string inFile, string outFile)
    {
        SevenZip.Compression.LZMA.Encoder coder = new SevenZip.Compression.LZMA.Encoder();
        FileStream input = new FileStream(inFile, FileMode.Open);
        FileStream output = new FileStream(outFile, FileMode.Create);

        coder.WriteCoderProperties(output);

        output.Write(System.BitConverter.GetBytes(input.Length), 0, 8);

        coder.Code(input, output, input.Length, -1, null);
        output.Flush();
        output.Close();
        input.Close();
    }

    /// <summary>
    /// 命令行参数解析
    /// </summary>
    static void ParseCommandArgs()
    {
        string[] args = System.Environment.GetCommandLineArgs();
        for (int i = 0; i < args.Length; )
        {
            if (args[i] == "-target")
            {
                target = (BuildTarget)System.Enum.Parse(typeof(BuildTarget), args[++i]);
            }
            else if (args[i] == "-output")
            {
                outputPath = args[++i];
            }
            else if (args[i] == "-files")
            {
                buildFiles = args[++i].Split(new char[] { ';' });
            }
            else if (args[i] == "-folders")
            {
                buildFolders = args[++i].Split(new char[] { ';' });
            }
            else if (args[i] == "-version")
            {
                version = args[++i];
            }
            else
            {
                ++i;
            }
        }
    }

    /// <summary>
    /// 生成场景
    /// </summary>
    static void BuildScenes()
    {
        foreach (string file in buildFiles)
        {
            if (string.IsNullOrEmpty(file) || Path.GetExtension(file) == ".meta")
                continue;
            if (!File.Exists(file))
                continue;
            foreach (string dep in AssetDatabase.GetDependencies(file))
            {
                skipAssets.Add(dep);
            }
            AssetBundleBuild build = new AssetBundleBuild()
            {
                assetBundleName = AssetDatabase.AssetPathToGUID(file),
                assetNames = new string[] { file },
            };
            BuildPipeline.BuildAssetBundles(Application.temporaryCachePath, new AssetBundleBuild[] { build },
                BuildAssetBundleOptions.DeterministicAssetBundle | BuildAssetBundleOptions.ChunkBasedCompression, target);
        }
    }
    /// <summary>
    /// 生成普通资源
    /// </summary>
    static void BuildResources()
    {
        foreach (string dir in buildFolders)
        {
            if (string.IsNullOrEmpty(dir) || dir.Contains(luaFolder) || dir.Contains(dataFolder))
                continue;
            BuildResource(dir);
        }
    }
    
    /// <summary>
    /// 生成一个文件夹下的资源
    /// </summary>
    /// <param name="root"></param>
    static void BuildResource(string root)
    {
        if (!Directory.Exists(root))
            return;

        string[] files = System.Array.FindAll(Directory.GetFiles(root), (file) =>
        {
            string ext = Path.GetExtension(file);
            if (ext == ".meta" || ext == ".unity")
                return false;
            foreach (string skip in skipAssets)
            {
                if (file == skip)
                    return false;
            }
            return true;
        });

        AddAssetBundleBuild(AssetDatabase.AssetPathToGUID(root), files);
    }

    /// <summary>
    /// 生成lua
    /// </summary>
    static void BuildLua()
    {
        if (!IsBuildFolder(luaFolder))
            return;

        CompileLua();

        string[] files = Directory.GetFiles(luaFolder, "*.bytes", SearchOption.AllDirectories);
        AddAssetBundleBuild(AssetDatabase.AssetPathToGUID(luaFolder), files);
    }

    /// <summary>
    /// 编译lua
    /// </summary>
    static void CompileLua()
    {
        string[] files = Directory.GetFiles(luaFolder, "*.txt", SearchOption.AllDirectories);
        foreach (string file in files)
        {
            LuaCompiler.Compile(file, target);
        }

        AssetDatabase.Refresh();
    }

    /// <summary>
    /// 清空lua字节码文件
    /// </summary>
    static void ClearLua()
    {
        if (!IsBuildFolder(luaFolder))
            return;

        string[] clearFiles = Directory.GetFiles(luaFolder, "*.bytes", SearchOption.AllDirectories);
        foreach (string file in clearFiles)
        {
            AssetDatabase.DeleteAsset(file);
        }
    }

    /// <summary>
    /// 生成数据
    /// </summary>
    static void BuildData()
    {
        if (!IsBuildFolder(dataFolder))
            return;

        EncryptData();

        string[] files = Directory.GetFiles(dataFolder, "*.bytes", SearchOption.AllDirectories);
        AddAssetBundleBuild(AssetDatabase.AssetPathToGUID(dataFolder), files);
    }

    /// <summary>
    /// 加密数据
    /// </summary>
    static void EncryptData()
    {
        string[] files = Directory.GetFiles(dataFolder, "*.txt", SearchOption.AllDirectories);
        foreach (string file in files)
        {
            DataEncryptor.Encrypt(file);
        }

        AssetDatabase.Refresh();
    }

    /// <summary>
    /// 清空加密数据
    /// </summary>
    static void ClearData()
    {
        if (!IsBuildFolder(dataFolder))
            return;

        string[] files = Directory.GetFiles(dataFolder, "*.bytes", SearchOption.AllDirectories);
        foreach (string file in files)
        {
            AssetDatabase.DeleteAsset(file);
        }
    }

    /// <summary>
    /// 将一个asset或者folder加入生成列表
    /// </summary>
    /// <param name="assetBundleName">asset bundle包名</param>
    /// <param name="assetNames">资源名</param>
    static void AddAssetBundleBuild(string assetBundleName, string[] assetNames)
    {
        if (assetNames == null || assetNames.Length == 0)
            return;

        // 获取依赖
        HashSet<string> deps = new HashSet<string>();
        foreach (string dep in AssetDatabase.GetDependencies(assetNames))
        {
            if (!IsAssetFolder(dep))
                continue;
            deps.Add(AssetDatabase.AssetPathToGUID(Path.GetDirectoryName(dep)));
        }
        deps.Remove(assetBundleName);

        // 创建依赖文件
        string depAssetName = dependencyFolder + assetBundleName + "_dep.txt";
        StreamWriter writer = new StreamWriter(depAssetName, false, System.Text.Encoding.UTF8);
        foreach (string dep in deps)
        {
            writer.Write(dep + "\n");
        }
        writer.Close();
        AssetDatabase.Refresh();

        Array.Resize(ref assetNames, assetNames.Length + 1);
        assetNames[assetNames.Length - 1] = depAssetName;
        builds.Add(new AssetBundleBuild() { assetBundleName = assetBundleName, assetNames = assetNames });
    }

    /// <summary>
    /// 文件夹是否是资源文件夹
    /// </summary>
    /// <param name="dir"></param>
    /// <returns></returns>
    static bool IsAssetFolder(string dir)
    {
        foreach (string folder in assetFolders)
        {
            if (dir.Contains(folder))
                return true;
        }
        return false;
    }

    /// <summary>
    /// 文件夹是否需要被生成
    /// </summary>
    /// <param name="dir">文件夹</param>
    /// <returns></returns>
    static bool IsBuildFolder(string dir)
    {
        if (buildFolders == null)
            return false;

        foreach (string folder in buildFolders)
        {
            if (folder == "") continue;
            if (dir.Contains(folder))
                return true;
        }
        return false;
    }

    public static Dictionary<string, List<string>> allDeps = new Dictionary<string, List<string>>();
    public static void RebuildDatabase(string filter = null)
    {
        string[] allAssetPaths = null;
        if (string.IsNullOrEmpty(filter))
        {
            allAssetPaths = AssetDatabase.GetAllAssetPaths();
        }
        else
        {
            var guids = AssetDatabase.FindAssets(filter);
            allAssetPaths = new string[guids.Length];
            for (int i = 0; i < guids.Length; ++i)
            {
                allAssetPaths[i] = AssetDatabase.GUIDToAssetPath(guids[i]);
            }
        }

        // Map of Dependency -> Assets with the dependency
       // allDeps = new Dictionary<string, List<string>>();
        allDeps.Clear();

        // Build dependency mapping for all assets in the project
        for (int p = 0; p < allAssetPaths.Length; p++)
        {
            if (p % 20 == 0)
            {
                var cancel = EditorUtility.DisplayCancelableProgressBar("Building Dependency Database", allAssetPaths[p], (float)p / allAssetPaths.Length);
                if (cancel)
                {
                    //allDeps = null;
                    allDeps.Clear();
                    break;
                }
            }

            var currentAsset = allAssetPaths[p];

            // Get dependencies for the current asset we're looping over
            var depsForCurrentAsset = AssetDatabase.GetDependencies(new string[] { currentAsset });

            for (int d = 0; d < depsForCurrentAsset.Length; d++)
            {

                var currentDependency = depsForCurrentAsset[d];

                // Flip it around, instead of storing asset -> list of dependencies for asset,
                // Store dependency -> list of assets relying upon the dependency

                List<string> assetsUsingDependency;

                // Get a list of all assets that rely on the dependency
                var entryExists = allDeps.TryGetValue(currentDependency, out assetsUsingDependency);
                if (!entryExists)
                    allDeps[currentDependency] = new List<string>();

                allDeps[currentDependency].Add(currentAsset);
            }
        }

        EditorUtility.ClearProgressBar();
    }
}
