﻿using UnityEngine;
using UnityEditor;
using System.IO;

public class CustomAssetImporter : AssetPostprocessor
{
#region PreProcessors
    private void OnPreprocessTexture()
    {
        Object asset = AssetDatabase.LoadAssetAtPath(assetImporter.assetPath, typeof(Texture2D));
        if (asset)
        {
            EditorUtility.SetDirty(asset);
        }
        else
        {
            TextureImporter importer = assetImporter as TextureImporter;
            if (assetPath.Contains("UI"))
            {
				if (!assetPath.Contains("BG"))
				{
					importer.textureType = TextureImporterType.Sprite;
					importer.mipmapEnabled = false;
                    importer.textureFormat = TextureImporterFormat.AutomaticCompressed;
				}
				else
				{
					importer.textureType = TextureImporterType.Advanced;
					importer.mipmapEnabled = false;
					importer.wrapMode = TextureWrapMode.Repeat;
					importer.textureFormat = TextureImporterFormat.AutomaticTruecolor;
				}
               
            }
            else
            {
                importer.textureType = CustomAssetImporterSetting.textureType;
                importer.spriteImportMode = SpriteImportMode.None;
            }
        } 
    }

    private void OnPreprocessModel()
    {
        ModelImporter importer = assetImporter as ModelImporter;
        importer.isReadable = false;
    }
#endregion

#region PostProcessors
    private void OnPostprocessTexture(Texture2D texture)
    {
        TextureImporter importer = assetImporter as TextureImporter;
        if (assetPath.Contains("UI") && !assetPath.Contains("BG"))
        {
            string tag = new DirectoryInfo(Path.GetDirectoryName(assetPath)).Name;
            importer.spritePackingTag = tag;
        }
        else
        {
            importer.spritePackingTag = string.Empty;
        }
    }
#endregion
}
