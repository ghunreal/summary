﻿using UnityEngine;
using System.Collections;
using System.IO;
using UnityEditor;


//[InitializeOnLoad]
public class LoadGMData
{
    // Use this for initialization
    static  LoadGMData()
    {
        #if UNITY_EDITOR
		//GameManagerSys  gms = GameManagerSys.GetInstance();
		//TextAsset csv = EditorGUIUtility.Load("Data/GM.txt") as TextAsset;
		//CSVReader.LoadText(csv.text, (object[] values) =>
		//{
		//	gms.AddWord((string)values[1], (string)values[2]);
		//});
        #endif
	}
}
