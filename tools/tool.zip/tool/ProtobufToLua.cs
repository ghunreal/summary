﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;

public class ProtobufToLua : EditorWindow
{
    private class ProtoEntry
    {
        public string filename;
        public bool selected;
    }
    private static List<ProtoEntry> protos = new List<ProtoEntry>();
    private static Vector2 scrollPos;
    public static string outputPath = "Assets/Scripts/Slua/Resources/pb/";

    [MenuItem("Export/Protobuf To Lua")]
    public static void ShowWindow()
    {
        EditorWindow.GetWindow<ProtobufToLua>();
    }

    void OnEnable()
    {
        protos.Clear();

        string[] files = Directory.GetFiles("Assets/Editor/IFProto/", "*.proto");
        foreach (string file in files)
        {
            protos.Add(new ProtoEntry() { filename = file });
        }
    }

    void OnGUI()
    {
        GUILayout.Label("Protobuf files", EditorStyles.boldLabel);

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Selecte All"))
            foreach (ProtoEntry proto in protos) proto.selected = true;
        if (GUILayout.Button("Unselect All"))
            foreach (ProtoEntry proto in protos) proto.selected = false;
        GUILayout.EndHorizontal();

        scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.Height(200));
        foreach (ProtoEntry proto in protos)
        {
            proto.selected = GUILayout.Toggle(proto.selected, proto.filename);
        }
        GUILayout.EndScrollView();

        if (GUILayout.Button("Export", EditorStyles.miniButtonMid))
        {
            Lexer.ResetReserved();
            Export();
        }
    }

    void Export()
    {
        if (!Directory.Exists(outputPath))
            Directory.CreateDirectory(outputPath);

        bool success = true;
        foreach (ProtoEntry proto in protos)
        {
            Lexer.ResetReserved();

            if (!proto.selected)
                continue;

            try
            {
                Parser parser = new Parser(proto.filename);
                parser.Export();
            }
            catch (System.Exception ex)
            {
                success = false;
                Debug.LogErrorFormat("Error ({0}): {1}", proto.filename, ex.Message);
                break;
            }
        }

        if (success)
        {
            Debug.Log("Export protobuf to lua finished");
            AssetDatabase.Refresh();
        }
    }
}


// Protobuf Token
enum ProtoToken
{
	Package,
    Import,
    Enum, Message,
    LeftBrace, RightBrace, Equal, Semicolon, Dot,
    ID, Number, Modifier, Type, String,
    Comment,
    EOF,
}

// 词法分析器
class Lexer
{
    private char[] buffer;
    private int current;
    private int last;
    private int line;
    private string lastId;
    private int lastNumber;
    private string lastString;
    private static Dictionary<string, ProtoToken> reserved = new Dictionary<string, ProtoToken>();

    public static void ResetReserved()
    {
        reserved.Clear();

		reserved["package"] = ProtoToken.Package;
        reserved["import"] = ProtoToken.Import;
        reserved["enum"] = ProtoToken.Enum;
        reserved["message"] = ProtoToken.Message;

        reserved["optional"] = ProtoToken.Modifier;
        reserved["repeated"] = ProtoToken.Modifier;

        reserved["string"] = ProtoToken.Type;
        reserved["float"] = ProtoToken.Type;
        reserved["double"] = ProtoToken.Type;
        reserved["bytes"] = ProtoToken.Type;
        reserved["int16"] = ProtoToken.Type;
        reserved["uint16"] = ProtoToken.Type;
        reserved["int32"] = ProtoToken.Type;
        reserved["uint32"] = ProtoToken.Type;
        reserved["int64"] = ProtoToken.Type;
        reserved["uint64"] = ProtoToken.Type;
        reserved["bool"] = ProtoToken.Type;
        reserved["tps"] = ProtoToken.Type;
    }

    private static Encoding GetType(FileStream fs)
    {
        Encoding reVal = Encoding.Default;

        BinaryReader r = new BinaryReader(fs, System.Text.Encoding.Default);
        int i;
        int.TryParse(fs.Length.ToString(), out i);
        byte[] ss = r.ReadBytes(i);
        if (IsUTF8Bytes(ss) || (ss[0] == 0xEF && ss[1] == 0xBB && ss[2] == 0xBF))
        {
            reVal = Encoding.UTF8;
        }
        else if (ss[0] == 0xFE && ss[1] == 0xFF && ss[2] == 0x00)
        {
            reVal = Encoding.BigEndianUnicode;
        }
        else if (ss[0] == 0xFF && ss[1] == 0xFE && ss[2] == 0x41)
        {
            reVal = Encoding.Unicode;
        }
        r.Close();
        return reVal;
    }

    private static bool IsUTF8Bytes(byte[] data)
    {
        int charByteCounter = 1; //计算当前正分析的字符应还有的字节数
        byte curByte; //当前分析的字节.
        for (int i = 0; i < data.Length; i++)
        {
            curByte = data[i];
            if (charByteCounter == 1)
            {
                if (curByte >= 0x80)
                {
                    //判断当前
                    while (((curByte <<= 1) & 0x80) != 0)
                        charByteCounter++;
                    //标记位首位若为非0 则至少以2个1开始 如:110XXXXX...........1111110X 
                    if (charByteCounter == 1 || charByteCounter > 6)
                        return false;
                }
            }
            else
            {
                //若是UTF-8 此时第一位必须为1
                if ((curByte & 0xC0) != 0x80)
                    return false;
                charByteCounter--;
            }
        }
        if (charByteCounter > 1)
            throw new System.Exception("非预期的byte格式");
        return true;
    }

    public Lexer(string filename)
    {
        FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
        Encoding r = GetType(fs);
        fs.Close();

        buffer = File.ReadAllText(filename, r).ToCharArray();
        current = 0;
        last = current;
        line = 1;
    }

    public ProtoToken Next()
    {
        last = current;
        while (current < buffer.Length)
        {
            char c = buffer[current++];
            switch (c)
            {
                case '\n': // 换行
                    line++;
                    break;

                case '\r': case '\t': case ' ':
                    break;

                case '/': // 注释
                    if (current + 1 >= buffer.Length || buffer[current++] != '/')
                        throw new System.Exception(string.Format("Unknown token '/' at line: {0}", line));
                    else
                        return ProtoToken.Comment;

                case '{':
                    return ProtoToken.LeftBrace;

                case '}':
                    return ProtoToken.RightBrace;

                case ';':
                    return ProtoToken.Semicolon;

                case '=':
                    return ProtoToken.Equal;

                case '.':
                    return ProtoToken.Dot;

                case '"':
                    return CheckString();

                default:
                    if (IsDigital(c)) // 数字
                        return CheckNumber();
                    else if (IsAlpha(c)) // 标识符
                        return CheckId();
                    else
                        throw new System.Exception(string.Format("Unknown token at line: {0}", line));
            }
        }

        return ProtoToken.EOF;
    }

    public void Until(char until)
    {
        while (current < buffer.Length)
        {
            if (buffer[current++] == until)
                break;
        }
    }

    public void Revert()
    {
        current = last;
    }

    public static void AddCustomType(string type)
    {
        reserved[type] = ProtoToken.Type;
    }

    public string ReadLine()
    {
        List<char> line = new List<char>();
        do
        {
            char c = buffer[current];
            if (c == '\n')
            {
                break;
            }
            else if (c == '\r')
            {
                if (current + 1 < buffer.Length && buffer[current + 1] == '\n')
                    ++current;
                break;
            }

            line.Add(buffer[current++]);
        } while (current < buffer.Length);

        return new string(line.ToArray());
    }

    public int Line { get { return line; } }
    public string LastID { get { return lastId; } }
    public int LastNumber { get { return lastNumber; } }
    public string LastString { get { return lastString; } }

    ProtoToken CheckNumber()
    {
        List<char> temp = new List<char>();
        current = current - 1;

        do
        {
            char c = buffer[current];
            if (c == '\n' || c == ';' || c == ' ')
                break;
            else if (!IsDigital(c))
                throw new System.Exception(string.Format("Error number type at line: {0}", line));

            temp.Add(c);
            ++current;
        } while (current < buffer.Length);

        lastNumber = System.Int32.Parse(new string(temp.ToArray()));
        return ProtoToken.Number;
    }

    ProtoToken CheckId()
    {
        List<char> temp = new List<char>();
        current = current - 1;

        do
        {
            char c = buffer[current];
            if (!(IsAlpha(c) || IsDigital(c)))
                break;

            temp.Add(c);
            ++current;
        } while (current < buffer.Length);

        lastId = new string(temp.ToArray());
        ProtoToken token;
        if (!reserved.TryGetValue(lastId, out token))
            return ProtoToken.ID;
        return token;
    }

    ProtoToken CheckString()
    {
        List<char> temp = new List<char>();
        
        do
        {
            char c = buffer[current++];
            if (c == '"')
                break;

            temp.Add(c);
        } while (current < buffer.Length);

        lastString = new string(temp.ToArray());
        return ProtoToken.String;
    }

    bool IsDigital(char c)
    {
        if (c >= '0' && c <= '9')
            return true;
        return false;
    }

    bool IsAlpha(char c)
    {
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_')
            return true;
        return false;
    }
}

// 语法分析器
class Parser
{
    private class MemberEntry
    {
        public string id;
        public string type;
        public string comment;
        public int index;
        public bool isRepeated;
    }

    private class SortMember : IComparer<MemberEntry>
    {
        public int Compare(MemberEntry a, MemberEntry b)
        {
            return a.index - b.index;
        }
    }

    private Lexer lexer;
    private string outputPath;
    private StreamWriter writer;
    private static Dictionary<string, System.Type> systemTypes = new Dictionary<string, System.Type>();

    static Parser()
    {
        systemTypes["string"] = typeof(System.String);
        systemTypes["float"] = typeof(System.Single);
        systemTypes["double"] = typeof(System.Double);
        systemTypes["int16"] = typeof(System.Int16);
        systemTypes["uint16"] = typeof(System.UInt16);
        systemTypes["int32"] = typeof(System.Int32);
        systemTypes["uint32"] = typeof(System.UInt32);
        systemTypes["int64"] = typeof(System.Int64);
        systemTypes["uint64"] = typeof(System.UInt64);
        systemTypes["bool"] = typeof(System.Boolean);
        systemTypes["tps"] = typeof(System.Nullable);
    }

    public Parser(string filename)
    {
        lexer = new Lexer(filename);
        outputPath = ProtobufToLua.outputPath + Path.GetFileNameWithoutExtension(filename) + ".txt";
    }

    public void Export()
    {
        writer = new StreamWriter(outputPath, false, System.Text.Encoding.UTF8);
        writer.WriteLine("tps = tps or {}");

        try
        {
            do
            {

                ProtoToken token = lexer.Next();
                if (token == ProtoToken.EOF)
                    break;
                else if (token == ProtoToken.Package)
                    lexer.ReadLine();
                else if (token == ProtoToken.Import)
                    Import(lexer, writer);
                else if (token == ProtoToken.Comment)
                    writer.WriteLine("--{0}", lexer.ReadLine());
                else if (token == ProtoToken.Enum)
                    ExportEnum();
                else if (token == ProtoToken.Message)
                    ExportMessage();
            } while (true);
        }
        catch
        {
            throw;
        }
        finally
        {
            writer.Close();
        }
    }

    void Import(Lexer lexer, StreamWriter writer)
    {
        ProtoToken token = lexer.Next();
        if (token != ProtoToken.String)
            throw new System.Exception(string.Format("Expected 'String' but token is of type '{0}' at line: {2}", token.ToString(), lexer.Line));

        if (writer != null)
            writer.WriteLine("\r\nrequire('pb/{0}')\r\n", Path.GetFileNameWithoutExtension(lexer.LastString));

        Lexer importer = new Lexer("Assets/Editor/IFProto/" + lexer.LastString);
        do
        {
            token = importer.Next();
            if (token == ProtoToken.EOF)
                break;
            else if (token == ProtoToken.Package)
                importer.ReadLine();
            else if (token == ProtoToken.Import)
                Import(importer, null);
            else if (token == ProtoToken.Comment)
                importer.ReadLine();
            else if (token == ProtoToken.Enum)
                ImportEnum(importer);
            else if (token == ProtoToken.Message)
                ImportMessage(importer);
        } while (true);
    }

    void ImportEnum(Lexer importer)
    {
        ProtoToken token = importer.Next();
        if (token != ProtoToken.ID)
            throw new System.Exception(string.Format("Expected 'ID' but token is of type '{0}' at line: {1}", token.ToString(), importer.Line));

        string enumName = importer.LastID;
        Lexer.AddCustomType(enumName);
        importer.Until('}');
    }

    void ImportMessage(Lexer importer)
    {
        ProtoToken token = importer.Next();
        if (token != ProtoToken.ID)
            throw new System.Exception(string.Format("Expected 'ID' but token is of type '{0}' at lien: {1}", token.ToString(), importer.Line));

        string messageName = importer.LastID;
        Lexer.AddCustomType(messageName);
        importer.Until('}');
    }

    // 解析枚举类型
    void ExportEnum()
    {
        string enumName;
        ExpectId(out enumName);
        ExpectToken(ProtoToken.LeftBrace);

        writer.WriteLine("{0} =", enumName);
        writer.WriteLine("{");

        while (true)
        {
            ProtoToken token = lexer.Next();
            if (token == ProtoToken.RightBrace)
            {
                // 解析完成，添加自定义类型
                Lexer.AddCustomType(enumName);
                break;
            }
            else if (token == ProtoToken.ID)
            {
                string id = lexer.LastID;
                int number;

                ExpectToken(ProtoToken.Equal);
                ExpectNumber(out number);
                ExpectToken(ProtoToken.Semicolon);

                if (lexer.Next() == ProtoToken.Comment)
                {
                    writer.WriteLine("\t{0} = {1}, --{2}", id, number, lexer.ReadLine());
                }
                else
                {
                    writer.WriteLine("\t{0} = {1},", id, number);
                    lexer.Revert();
                }
            }
            else if (token == ProtoToken.Comment)
            {
                writer.WriteLine("\t--{0}", lexer.ReadLine());
            }
            else
            {
                throw new System.Exception(string.Format("Unknown token '{0}' at line: {1}", token.ToString(), lexer.Line));
            }
        }

        writer.WriteLine("}\n");
    }

    // 解析协议类型
    void ExportMessage()
    {
        string messageName;
        ExpectId(out messageName);
        ExpectToken(ProtoToken.LeftBrace);

        writer.WriteLine("{0} = Slua.Class(UnityEngine.Object,", messageName);

        List<MemberEntry> members = new List<MemberEntry>();

        while (true)
        {
            ProtoToken token = lexer.Next();
            if (token == ProtoToken.RightBrace)
            {
                // 解析完成，添加自定义类型
                Lexer.AddCustomType(messageName);
                break;
            }
            else if (token == ProtoToken.Modifier)
            {
                MemberEntry member = new MemberEntry();
                member.isRepeated = lexer.LastID == "repeated";

                ExpectType(out member.type);
                // ignore package name
                if (member.type == "tps")
                {
                    ExpectToken(ProtoToken.Dot);
                    ExpectType(out member.type);
                }
                ExpectId(out member.id);
                ExpectToken(ProtoToken.Equal);
                ExpectNumber(out member.index);
                ExpectToken(ProtoToken.Semicolon);

                if (lexer.Next() == ProtoToken.Comment)
                    member.comment = lexer.ReadLine();
                else
                    lexer.Revert();

                members.Add(member);
            }
            else if (token == ProtoToken.Comment)
            {
                writer.WriteLine("\t--{0}", lexer.ReadLine());
            }
            else
            {
                throw new System.Exception(string.Format("Unknown token '{0}' at line: {1}", token.ToString(), lexer.Line));
            }
        }

        // index是Protobuf序列化的重要参数，按index排序，如果index从1开始，则可以让其等于lua中的次序索引
        members.Sort(new SortMember());

        // 写入成员信息
        writer.WriteLine("{");
        foreach (MemberEntry member in members)
        {
            if (member.type == "bytes") // 字节类型特殊处理
            {
                writer.Write("\t{{ name = '{0}', type = 'System.Array', item = 'System.Byte' }},", member.id);
            }
            else
            {
                System.Type type = GetSystemType(member.type);
                if (type != null) // 系统类型
                {
                    if (member.isRepeated)
                        writer.Write("\t{{ name = '{0}', type = 'LuaTable', item = '{1}' }},", member.id, type.ToString());
                    else
                        writer.Write("\t{{ name = '{0}', type = '{1}' }},", member.id, type.ToString());
                }
                else // 自定义类型
                {
                    if (member.isRepeated)
                        writer.Write("\t{{ name = '{0}', type = 'LuaTable', item = '{1}' }},", member.id, member.type);
                    else
                        writer.Write("\t{{ name = '{0}', type = '{1}' }},", member.id, member.type);
                }
            }

            if (!string.IsNullOrEmpty(member.comment))
                writer.Write(" --{0}\n", member.comment);
            else
                writer.Write("\n");
        }
        writer.WriteLine("},");

        // 写入成员初始化值
        writer.WriteLine("{");
        foreach (MemberEntry member in members)
        {
			if (member.isRepeated)
				writer.WriteLine("\t{0} = {{}},", member.id);
			else if (member.type == "string" || member.type == "bytes")
				writer.WriteLine("\t{0} = '',", member.id);
			else if (member.type == "bool")
				writer.WriteLine("\t{0} = false,", member.id);
			else if (member.type == "uint64")
				writer.WriteLine("\t{0} = 'AAAAAAAAAAA=',", member.id);
			else
				writer.WriteLine("\t{0} = 0,", member.id);
        }

        // 构造函数和结尾
        writer.WriteLine("\tctor = function(self) self.__class = {0} end,", messageName);
        writer.WriteLine("})");
        writer.WriteLine("table.insert(tps, {0})\n", messageName);
    }

    void ExpectToken(ProtoToken expect)
    {
        ProtoToken token = lexer.Next();
		while (expect != token)
		{
			if (token == ProtoToken.Comment)
				lexer.ReadLine();
			else
				throw new System.Exception(string.Format("Expected '{0}' but token is of type '{1}' at line: {2}", expect.ToString(), token.ToString(), lexer.Line));
			token = lexer.Next();
		}
    }

    void ExpectType(out string type)
    {
        ExpectToken(ProtoToken.Type);
        type = lexer.LastID;
    }

    void ExpectId(out string id)
    {
        ExpectToken(ProtoToken.ID);
        id = lexer.LastID;
    }

    void ExpectNumber(out int number)
    {
        ExpectToken(ProtoToken.Number);
        number = lexer.LastNumber;
    }

    System.Type GetSystemType(string type)
    {
        System.Type systemType;
        if (systemTypes.TryGetValue(type, out systemType))
            return systemType;
        return null;
    }
}