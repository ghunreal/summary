﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.IO;

public class DirectoryCleaner
{
	#region menu item
	[MenuItem("Tools/Clean Directory")]
	private static void CleanDirectory()
	{
		string root = Application.dataPath;
		Clean(root);

		EditorUtility.DisplayDialog("Clean Directory", "Finished. Please commit to git repotory.", "OK");

		return;
	}
	#endregion menu item

	#region private imp
	private static void Clean(string dir)
	{
		string[] subDirs = Directory.GetDirectories(dir);
		foreach (string subDir in subDirs)
			Clean(subDir);

		if (IsEmpty(dir)) {
			DeleteDirectoryAndMeta(dir);
			return;
		}

		return;
	}

	private static bool IsEmpty(string dir)
	{
		string[] subDirs = Directory.GetDirectories(dir);
		string[] files = Directory.GetFiles(dir);

		if (subDirs.Length == 0 && files.Length == 0)
			return true;

		return false;
	}

	private static void DeleteDirectoryAndMeta(string dir)
	{
		string name = dir + ".meta";
		try {
			// get rid of directory and meta file of that directory
			Directory.Delete(dir);
			File.Delete(name);
		}
		catch (System.Exception e) {
			Debug.Log(e.Message);
		}

		return;
	}
	#endregion private imp
}
