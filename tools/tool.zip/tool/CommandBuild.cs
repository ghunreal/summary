﻿using UnityEngine;
using UnityEditor;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;


/// <summary>
/// 命令行编译
/// </summary>
public class CommandBuild {
    private static string outputPath = string.Empty;
    private static string[] levels;
    private static bool isDebug = true;
    private static string version;

    /// <summary>lua文件夹</summary>
    private static readonly string LUA_FOLDER = "Assets/Scripts/Slua/Resources";
    /// <summary>data文件夹</summary>
    private static readonly string DATA_FOLDER = "Assets/Resources/Data";
    /// <summary>lua临时文件夹，用来保存.txt原始文件</summary>
    private static readonly string LUA_TEMP_FOLDER = Application.temporaryCachePath + "/lua";
    /// <summary>data临时文件夹，用来保存.txt原始文件</summary>
    private static readonly string DATA_TEMP_FOLDER = Application.temporaryCachePath + "/data";

    /// <summary>
    /// 解析命令行参数
    /// </summary>
    static void ParseCommandArgs()
    {
        string[] args = System.Environment.GetCommandLineArgs();
        for (int i = 0; i < args.Length; )
        {
            if (args[i] == "-output")
                outputPath = args[++i];
            else if (args[i] == "-debug")
                isDebug = System.Boolean.Parse(args[++i]);
            else if (args[i] == "-version")
                version = args[++i];
            else
                ++i;
        }
    }

    /// <summary>
    /// 编译预处理
    /// </summary>
    /// <param name="target">编译目标</param>
    static void PreBuild(BuildTarget target)
    {
        // 删除可能残留的临时文件
        if (Directory.Exists(LUA_TEMP_FOLDER)) Directory.Delete(LUA_TEMP_FOLDER, true);
        if (Directory.Exists(DATA_TEMP_FOLDER)) Directory.Delete(DATA_TEMP_FOLDER, true);

        outputPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

        ParseCommandArgs();

        EditorUserBuildSettings.SwitchActiveBuildTarget(target);

        // 创建输出目录
        if (!string.IsNullOrEmpty(outputPath) && !Directory.Exists(outputPath))
            Directory.CreateDirectory(outputPath);

        // 添加需要被编译的level
		List<string> temp = new List<string>();
        for (int i = 0; i < EditorBuildSettings.scenes.Length; ++i)
        {
			if (EditorBuildSettings.scenes[i].enabled)
				temp.Add(EditorBuildSettings.scenes[i].path);
        }
		levels = temp.ToArray();

        CompileLua(target);
        EncryptData();
#if USE_RES_ATLAS
        AtlasCreator.CreateAtlasPrefab();
#endif // USE_RES_ATLAS

        PlayerSettings.bundleVersion = version;
    }

    /// <summary>
    /// 编译后处理
    /// </summary>
    static void PostBuild()
    {
        ClearLua();
        ClearData();
#if USE_RES_ATLAS
        AtlasCreator.Revert();
#endif // USE_RES_ATLAS
    }

    /// <summary>
    /// 编译lua
    /// </summary>
    /// <param name="target"></param>
    static void CompileLua(BuildTarget target)
    {
        string[] files = Directory.GetFiles(LUA_FOLDER, "*.txt", SearchOption.AllDirectories);
        foreach (string file in files)
        {
            LuaCompiler.Compile(file, target);

            // Move lua files to temp folder
            string destFilename = file.Replace(LUA_FOLDER, LUA_TEMP_FOLDER);
            if (!Directory.Exists(Path.GetDirectoryName(destFilename)))
                Directory.CreateDirectory(Path.GetDirectoryName(destFilename));
            File.Copy(file, destFilename);
            File.Copy(file + ".meta", destFilename + ".meta");
            AssetDatabase.DeleteAsset(file);
        }

        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
    }

    /// <summary>
    /// 清理lua的字节码文件
    /// </summary>
    static void ClearLua()
    {
		if (!Directory.Exists(LUA_TEMP_FOLDER))
			return;
		
        // Delete lua bytes files
        string[] files = Directory.GetFiles(LUA_FOLDER, "*.bytes", SearchOption.AllDirectories);
        foreach (string file in files)
        {
            AssetDatabase.DeleteAsset(file);
        }

        // Move lua files back to Resources folder
        files = Directory.GetFiles(LUA_TEMP_FOLDER, "*.*", SearchOption.AllDirectories);
        foreach (string file in files)
        {
            string destFilename = file.Replace(LUA_TEMP_FOLDER, LUA_FOLDER);
            File.Copy(file, destFilename);
        }
        Directory.Delete(LUA_TEMP_FOLDER, true);

        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
    }

    /// <summary>
    /// 加密数据
    /// </summary>
    static void EncryptData()
    {
        string[] files = Directory.GetFiles(DATA_FOLDER, "*.txt", SearchOption.AllDirectories);
        foreach (string file in files)
        {
            DataEncryptor.Encrypt(file);

            // Move data files to temp folder
            string destFilename = file.Replace(DATA_FOLDER, DATA_TEMP_FOLDER);
            if (!Directory.Exists(Path.GetDirectoryName(destFilename)))
                Directory.CreateDirectory(Path.GetDirectoryName(destFilename));
            File.Copy(file, destFilename);
            File.Copy(file + ".meta", destFilename + ".meta");
            AssetDatabase.DeleteAsset(file);
        }

        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
    }

    /// <summary>
    /// 清理加密后数据文件
    /// </summary>
    static void ClearData()
    {
        // Delete data bytes files
        string[] files = Directory.GetFiles(DATA_FOLDER, "*.bytes", SearchOption.AllDirectories);
        foreach (string file in files)
        {
            AssetDatabase.DeleteAsset(file);
        }

        // Move data files back to Resources folder
        files = Directory.GetFiles(DATA_TEMP_FOLDER, "*.*", SearchOption.AllDirectories);
        foreach (string file in files)
        {
            string destFilename = file.Replace(DATA_TEMP_FOLDER, DATA_FOLDER);
            File.Copy(file, destFilename);
        }
        Directory.Delete(DATA_TEMP_FOLDER, true);

        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
    }

    [MenuItem("Build/Build Android")]
    public static void BuildAndroid()
    {
        PreBuild(BuildTarget.Android);
        BuildPipeline.BuildPlayer(levels, outputPath + "/IF.apk", BuildTarget.Android, isDebug ? BuildOptions.Development : BuildOptions.None);
        PostBuild();
    }

    [MenuItem("Build/Build iOS")]
    public static void BuildiOS()
    {
        PreBuild(BuildTarget.iOS);
        BuildPipeline.BuildPlayer(levels, outputPath + "/xcode", BuildTarget.iOS, isDebug ? BuildOptions.Development : BuildOptions.None);
        PostBuild();
    }

    [MenuItem("Build/Build StandaloneWindows64")]
    public static void BuildStandaloneWindows64()
    {
        PreBuild(BuildTarget.StandaloneWindows64);
        BuildPipeline.BuildPlayer(levels, outputPath + "/IF.exe", BuildTarget.StandaloneWindows64, isDebug ? BuildOptions.Development : BuildOptions.None);
        PostBuild();
    }
}
