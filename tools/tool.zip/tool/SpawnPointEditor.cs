﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

[CustomEditor(typeof(SpawnPoint))]
public class SpawnPointEditor : Editor
{

    void OnEnable()
    {
        SceneView.onSceneGUIDelegate += CustomSceneGUI;
    }

    void OnDisable()
    {
        SceneView.onSceneGUIDelegate -= CustomSceneGUI;
    }

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        SpawnPoint pt = target as SpawnPoint;

        GUILayout.Label("Size = " + pt.points.Count);
        List<string> outputs = new List<string>();
        for (int i = 0; i < pt.points.Count; ++i)
        {
            outputs.Add(string.Format("{0:#0.00};{1:#0.00}", pt.points[i].x, pt.points[i].z));
        }
        GUILayout.TextField(string.Join(";", outputs.ToArray()));
        List<string> distances = new List<string>();
        distances.Add("0.00");
        for (int i = 1; i < pt.points.Count; ++i)
        {
            distances.Add(string.Format("{0:#.00}", Vector3.Distance(pt.points[i], pt.points[i - 1])));
        }
        GUILayout.TextField(string.Join(";", distances.ToArray()));

        if (GUILayout.Button("Add"))
        {
            pt.points.Add(pt.points[pt.points.Count - 1] + GetForward(pt.points.Count - 1) * 10.0f);
            Repaint();
        }
        if (GUILayout.Button("Clear"))
        {
            pt.points.Clear();
            pt.points.Add(pt.transform.position + pt.transform.forward * 10.0f + pt.transform.right * 10.0f);
            pt.points.Add(pt.transform.position + pt.transform.forward * 10.0f - pt.transform.right * 10.0f);
            pt.points.Add(pt.transform.position - pt.transform.forward * 10.0f - pt.transform.right * 10.0f);
            pt.points.Add(pt.transform.position - pt.transform.forward * 10.0f + pt.transform.right * 10.0f);
        }
        if (GUILayout.Button("Copy"))
        {
            EditorGUIUtility.systemCopyBuffer = string.Join(";", outputs.ToArray());
        }
    }

    void CustomSceneGUI(SceneView sceneView)
    {
        SpawnPoint pt = target as SpawnPoint;

        for (int i = 0; i < pt.points.Count; ++i)
        {
            Handles.color = Color.white;
            Quaternion rot = Quaternion.FromToRotation(Vector3.right, GetForward(i));
            Vector3 newPos = Handles.FreeMoveHandle(pt.points[i], rot, 0.5f, Vector3.zero, Handles.RectangleCap);
            newPos.y = pt.transform.localPosition.y;
            if (newPos != pt.points[i])
                pt.points[i] = newPos;

            Vector3 p1 = pt.points[(i + 1) % pt.points.Count];
            Vector3 p0 = pt.points[(i + 0) % pt.points.Count];
            Handles.color = Color.red;
            Handles.DrawLine(p1, p0);
        }
    }

    Vector3 GetForward(int index)
    {
        SpawnPoint pt = target as SpawnPoint;

        if (index == 0)
            return pt.transform.forward;

        Vector3 p0 = pt.points[index - 1];
        Vector3 p1 = pt.points[index];
        return (p1 - p0).normalized;
    }
}
