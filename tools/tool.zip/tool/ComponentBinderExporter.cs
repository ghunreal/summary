﻿using System;
using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.IO;


public class ComponentBinderExporter : EditorWindow
{
    private string searchString = "";
    private Vector2 scrollPos;
    private static string COMPONENTS_START = "----------COMPONENTS BEGIN----------";
    private static string COMPONENTS_END = "----------COMPONENTS END----------";

    List<ComponentBinder.Entry> entries = new List<ComponentBinder.Entry>();

    private class PrefabEntry
    {
        public string filename;
        public bool selected;
    }
    List<PrefabEntry> allPrefabs = new List<PrefabEntry>();
    List<PrefabEntry> filterdPrefabs = new List<PrefabEntry>();
    [MenuItem("Custom/ComponentBinder")]
    public static void ShowWindow()
    {
        EditorWindow.GetWindow<ComponentBinderExporter>();
    }

    void OnEnable()
    {
        allPrefabs.Clear();
        string prefabFolder = "Assets/Resources/Prefabs/UI";
        if (Directory.Exists(prefabFolder))
        {
            string f = string.Empty;
            foreach (string file in Directory.GetFiles(prefabFolder, "*.prefab", SearchOption.AllDirectories))
            {
                f = file.Replace('\\', '/');
                allPrefabs.Add(new PrefabEntry() { filename = f.Substring(f.IndexOf("Prefabs")) });
            }
        }
        filterdPrefabs = allPrefabs;
    }

    void OnGUI()
    {
        GUILayout.BeginHorizontal(GUI.skin.FindStyle("Toolbar"));
        searchString = GUILayout.TextField(searchString, GUI.skin.FindStyle("ToolbarSeachTextField"));
        if (GUI.changed && !string.IsNullOrEmpty(searchString))
            filterdPrefabs = allPrefabs.FindAll(entry => entry.filename.IndexOf(searchString, 0, StringComparison.CurrentCultureIgnoreCase) != -1);
        if (GUILayout.Button("", GUI.skin.FindStyle("ToolbarSeachCancelButton")))
        {
            searchString = "";
            filterdPrefabs = allPrefabs;
            GUI.FocusControl(null);
        }
        GUILayout.EndHorizontal();

        GUILayout.Label("UI Prefabs", EditorStyles.boldLabel);

        // searchString = GUILayout.TextField(searchString, EditorStyles.textField);
        if (allPrefabs.Count > 0)
        {
            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.Height(200));
            foreach (PrefabEntry entry in filterdPrefabs)
            {
                entry.selected = GUILayout.Toggle(entry.selected, entry.filename);
            }
            GUILayout.EndScrollView();
            if (GUILayout.Button("Export", EditorStyles.miniButtonMid))
            {
                Export();
            }
        }
        else
        {
            GUILayout.Label("there is no ui prefabs");
        }
    }

    void Export()
    {
        foreach (PrefabEntry entry in allPrefabs)
        {
            if (entry.selected)
                Export(entry.filename.Replace(".prefab", ""));
        }

    }

    void Export(string filename)
    {
        GameObject go = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/" + filename + ".prefab");

        entries.Clear();
        ComponentBinder.TravelComponents(go, (key, type, value, index) =>
        {
            if (value is LuaBehavior)
                GameObject.DestroyImmediate(value, true);
            entries.Add(new ComponentBinder.Entry(key, type, value, index));
        });

        // 代码缓存
        List<string> codes = new List<string>();

        // 设置lua文件名
        string scriptName = "Assets/Scripts/Slua/Resources/" + Path.GetFileName(filename) + ".txt";

        // 文件已存在，将lua代码缓存
        if (File.Exists(scriptName))
        {
            StreamReader reader = new StreamReader(scriptName, System.Text.Encoding.UTF8);

            bool found = false;
            string line = null;
            while (!reader.EndOfStream)
            {
                line = reader.ReadLine();
                if (line == COMPONENTS_END)
                {
                    found = true;
                    continue;
                }

                // 已找到COMPONENTS_END注释，开始记录lua代码
                if (found)
                    codes.Add(line);
            }

            // 没有找到Components注释段，重新读取整个文件并缓存
            if (found == false)
            {
                reader.Close();
                reader = new StreamReader(scriptName, System.Text.Encoding.UTF8);
                while (!reader.EndOfStream)
                {
                    codes.Add(reader.ReadLine());
                }
            }

            reader.Close();
        }

        StreamWriter writer = new StreamWriter(scriptName, false, System.Text.Encoding.UTF8);

        // 写入Component注释段
        writer.WriteLine(COMPONENTS_START);
        foreach (ComponentBinder.Entry entry in entries)
        {
            if (entry.index == -1)
                writer.WriteLine("--{0} {1}", entry.type, entry.key);
            else
                writer.WriteLine("--{0} {1}[{2}]", entry.type, entry.key, entry.index);
        }
        writer.WriteLine(COMPONENTS_END);

        // 写入lua代码
        foreach (string code in codes)
        {
            writer.WriteLine(code);
        }

        writer.Close();
    }
}
