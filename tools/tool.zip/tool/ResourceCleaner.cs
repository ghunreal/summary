﻿using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections;
using System.Collections.Generic;

public class ResourceCleaner : EditorWindow
{
	private static readonly string CHECK_LOC = Application.dataPath + "/Content/SFX/Materials/";

	static List<string> allDepnedencies = new List<string>();

	[MenuItem("Utility/Clean Project (Time Consuming)")]
	public static void CleanResource()
	{
		string[] guids = AssetDatabase.FindAssets("t:Prefab", new string[] { @"Assets/Resources/Prefabs" });
		for (int i = 0; i < guids.Length; ++i) {
			// get path
			string path = AssetDatabase.GUIDToAssetPath(guids[i]);

			// get dependencies
			string[] temp = AssetDatabase.GetDependencies(path);
			allDepnedencies.AddRange(temp); // add to uniform location
			EditorUtility.DisplayProgressBar("Gatering dependencies", i + "/" + guids.Length + " " + path, (float)i / guids.Length);
		}
		EditorUtility.ClearProgressBar();

		CleanRedundencies(CHECK_LOC);

		return;
	}

	private static void CleanRedundencies(string dir)
	{
		string[] subDirs = Directory.GetDirectories(dir);
		foreach (string subDir in subDirs)
			CleanRedundencies(subDir);

		string[] files = Directory.GetFiles(dir);
		for (int i = 0; i < files.Length; ++i) {
			if (files[i].Contains(".meta"))
				continue;

			int lastIdx = files[i].LastIndexOf("Assets");
			int lastDot = files[i].LastIndexOf(".");
			string temp = files[i].Substring(lastIdx, files[i].Length - lastIdx);
			temp = temp.Replace("\\", "/");
			if (!allDepnedencies.Contains(temp))
				AssetDatabase.DeleteAsset(temp);
			EditorUtility.DisplayProgressBar("Deleting redundant files", temp, (float)i / files.Length);
		}
		EditorUtility.ClearProgressBar();

		AssetDatabase.Refresh();

		return;
	}
}
