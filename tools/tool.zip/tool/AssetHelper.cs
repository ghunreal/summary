﻿/// <summary>
/// AssetHelper 用于提供保存资源的辅助操作,目前仅有SFX目录下特效资源的序列化处理
/// </summary>
using UnityEngine;
using UnityEditor;
using System.IO;

public class AssetHelper : AssetModificationProcessor{
    private static readonly string SFXFOLDER = "SFX";

    [InitializeOnLoadMethod]
    static void StartInitializeOnLoadMethod()
    {
        // 注册Apply时的回调
        PrefabUtility.prefabInstanceUpdated = delegate(GameObject instance)
        {
            SaveEffectPrefab(instance);
        };
    }

    /// <summary>
    /// 当有Asset保存时自动调用
    /// </summary>
    /// <param name="paths"></param>
    /// <returns></returns>
    static string[] OnWillSaveAssets(string[] paths){
        // Debug.Log("OnWillSaveAssets");
        
        SaveEffectPrefabs(paths);
        return paths;
    }

    static void SaveEffectPrefabs(string[] paths)
    {
        foreach (string path in paths)
        {
            if(!IsEffectPrefab(path))
                continue;

            Debug.LogFormat("SaveEffectPrefabs {0}", path);

            GameObject prefab = (GameObject)AssetDatabase.LoadAssetAtPath(path, typeof(GameObject));
            if(prefab == null)
            {
                Debug.LogFormat("Can not load prefab {0}", path);
                continue;
            }

            GameObject go = UnityEngine.Object.Instantiate(prefab) as GameObject;
            SFXController sfxController = go.GetComponent<SFXController>();
            if (null == sfxController)
            {
                Debug.LogWarning(string.Format("{0} has not SFXController. You need add one, unless you sure that's not necessary!", path));
                continue;
            }

            sfxController.Init();
            PrefabUtility.ReplacePrefab(go, prefab);
            UnityEngine.Object.DestroyImmediate(go);
        }
    }

    static void SaveEffectPrefab(GameObject instance)
    {
        string prefabPath = AssetDatabase.GetAssetPath(PrefabUtility.GetPrefabParent(instance));
        if(!IsEffectPrefab(prefabPath))
            return;

        Debug.LogFormat("SaveEffectPrefab Path = {0}", prefabPath);
        SFXController sfxController = instance.GetComponent<SFXController>();
        if (null == sfxController)
        {
            string msg = string.Format("{0} has not a SFXController Component. You need add one, unless you sure that's not necessary!", prefabPath);
            EditorUtility.DisplayDialog("Apply a Effect prefab!", msg, "OK");
            return;
        }

        sfxController.Init();
    }


    static bool IsEffectPrefab(string path){
        if(path.Contains(SFXFOLDER) && Path.GetExtension(path) == ".prefab")
            return true;

        return false;
    }
}
