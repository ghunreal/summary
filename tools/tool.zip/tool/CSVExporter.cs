﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Text;
using System.IO;

public class CSVExporter : EditorWindow {
    private TextAsset csv;
    private Vector2 scrollPos;

    [MenuItem("Export/CSV")]
    public static void ShowWindow()
    {
        EditorWindow.GetWindow(typeof(CSVExporter));
    }

    void OnGUI()
    {
        Debug.LogWarning("wait for update~~~~");
        return;
        GUILayout.Label("File", EditorStyles.boldLabel);
        csv = EditorGUILayout.ObjectField("CSV File", csv, typeof(TextAsset), false) as TextAsset;

        if (csv != null)
        {
            GUILayout.Label("Preview", EditorStyles.boldLabel);
            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.Height(200));
            string[] names = null;
            string[] descs = null;
            System.Type[] types = null;
            string mainKey = string.Empty;
            string subKey = string.Empty;

            StringBuilder builder = new StringBuilder(512);
            //CSVReader.GetTypes(csv.text, out names, out types, out descs, out mainKey, out subKey);
            for (int i = 0; i < names.Length; ++i)
            {
                if (names[i] == string.Empty)
                    continue;

                builder.Remove(0, builder.Length);
                builder.Append(types[i].ToString());
                builder.Append(" ");
                builder.Append(names[i]);
                if (names[i] == mainKey || names[i] == subKey)
                {
                    builder.Append("(KEY)");
                    GUILayout.Label(builder.ToString(), EditorStyles.boldLabel);
                }
                else
                {
                    GUILayout.Label(builder.ToString(), EditorStyles.label);
                }
            }
            GUILayout.EndScrollView();

            if (GUILayout.Button("Export", EditorStyles.miniButtonMid))
            {
                //Export(csv.name, names, types, descs, mainKey, subKey);
            }
        }
    }

    void Export(string filename, string[] names, System.Type[] types, string[] descs, string mainKey, string subKey)
    {
        FileStream stream = new FileStream("Assets/Scripts/Data/" + filename + ".cs", FileMode.Create, FileAccess.Write);
        StreamWriter writer = new StreamWriter(stream, Encoding.UTF8);

        writer.WriteLine("using UnityEngine;");
        writer.WriteLine("using System.Collections;");
        writer.WriteLine("using System.Collections.Generic;");
        writer.WriteLine();

        writer.WriteLine("namespace csv {");
        writer.WriteLine("\tpublic class {0} {{", filename);

        // Properties
        for (int i = 0; i < names.Length; ++i)
        {
            if (names[i] == string.Empty)
                continue;

            writer.WriteLine("\t\t///<summary>{0}</summary>", descs[i]);
            writer.WriteLine("\t\tpublic {0} {1} {{ get; private set; }}", types[i].ToString(), names[i]);
        }
        writer.WriteLine();

        // Query method
        writer.WriteLine("\t\tprivate static Dictionary<long, {0}> datas = new Dictionary<long, {0}>();", filename);
        if (subKey == string.Empty)
        {
            writer.WriteLine("\t\tpublic static {0} Find(int {1}) {{", filename, mainKey);
            writer.WriteLine("\t\t\t{0} result = null;", filename);
            writer.WriteLine("\t\t\tlong key = (long){0} << 32;", mainKey);
            writer.WriteLine("\t\t\tif (datas.TryGetValue(key, out result))");
            writer.WriteLine("\t\t\t\treturn result;");
            writer.WriteLine("\t\t\treturn null;");
            writer.WriteLine("\t\t}"); // Find 
        }
        else
        {
            writer.WriteLine("\t\tpublic static {0} Find(int {1}, int {2}) {{", filename, mainKey, subKey);
            writer.WriteLine("\t\t\t{0} result = null;", filename);
            writer.WriteLine("\t\t\tlong key = ((long){0} << 32) + {1};", mainKey, subKey);
            writer.WriteLine("\t\t\tif (datas.TryGetValue(key, out result))");
            writer.WriteLine("\t\t\t\treturn result;");
            writer.WriteLine("\t\t\treturn null;");
            writer.WriteLine("\t\t}"); // Find
        }
        
        writer.WriteLine("\t\tpublic static Dictionary<long, {0}>.ValueCollection Values {{", filename);
        writer.WriteLine("\t\t\tget { return datas.Values; }");
        writer.WriteLine("\t\t}"); // Values
        writer.WriteLine();

        // Load method
        writer.WriteLine("\t\tpublic static bool Init() {");
        writer.WriteLine("\t\t\tCSVReader.Load(\"Data/{0}\", (System.Object[] values) => {{", filename);
        writer.WriteLine("\t\t\t\t{0} value = new {0}();", filename);

        for (int i = 0; i < names.Length; ++i)
        {
            if (names[i] == string.Empty)
                continue;

            writer.WriteLine("\t\t\t\tvalue.{0} = ({1})values[{2}];", names[i], types[i], i);
        }

        if (subKey == string.Empty)
            writer.WriteLine("\t\t\t\tdatas[(long)value.{0} << 32] = value;", mainKey);
        else
            writer.WriteLine("\t\t\t\tdatas[((long)value.{0} << 32) + value.{1}] = value;", mainKey, subKey);
        
        writer.WriteLine("\t\t\t});");
        writer.WriteLine("\t\t\treturn true;");
        writer.WriteLine("\t\t}"); // Init

        writer.WriteLine("\t}"); // class
        writer.WriteLine("}"); // namespace csv

        writer.Close();
        stream.Close();
    }
}
