﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;

public class FindAllReferences {

	[MenuItem("Assets/Find All References", false, 900)]
	static void FindAllReference() {
		string selectObjectPath = AssetDatabase.GetAssetPath(Selection.activeObject);
		Debug.Log("Target path:" + selectObjectPath );
		string[] results = GetReferencesPaths(selectObjectPath);
		Debug.Log(string.Format("---------------------------------------Reference Count: {0}", results.Length));
		foreach(string result in results) {
			Debug.Log( "Reference:" + result);
		}
		Debug.Log("---------------------------------------End Of Result!");
	}

	[MenuItem("Assets/Delete Unreferenced UI Pngs", false, 900)]
	static void DeleteUnreferencedUIPngs() {
		string[] contentUIPngPaths = GetAssetPaths("/Content/UI", "*.png");
		Dictionary<string, HashSet<string>> referenceDic = GetUIPrefabsReferencedDic();

		foreach (string contentUiPngPath in contentUIPngPaths) {
			if (!referenceDic.ContainsKey(contentUiPngPath)) {
				Debug.Log( "Unreferenced png path:" + contentUiPngPath );
//				AssetDatabase.DeleteAsset(contentUiPngPath);
			}
		}
	}

	private static Dictionary<string, HashSet<string>> GetUIPrefabsReferencedDic() {
		Dictionary < string, HashSet < string >> results = new Dictionary<string, HashSet<string>>();
		string[] prefabPaths = GetAssetPaths("/Resources/Prefabs/UI", "*.prefab");
		foreach (string prefabPath in prefabPaths) {
			string[] references = AssetDatabase.GetDependencies(prefabPath);
			foreach (string reference in references) {
				if ( reference.Substring(reference.LastIndexOf(".") + 1) == "png") {
					HashSet<string> allReferenced;
					if (!results.TryGetValue(reference, out allReferenced)) {
						allReferenced = new HashSet<string>();
						results.Add(reference,allReferenced);
					}
					allReferenced.Add(prefabPath);
				}
			}
		}
		return results;
	}

	private static string[] GetReferencesPaths( string targetPath ) {
		string[] prefabPaths = GetAssetPaths("/Resources/Prefabs/UI", "*.prefab");
		List<string> results = new List<string>();
		foreach (string prefabPath in prefabPaths) {
			string[] references = AssetDatabase.GetDependencies(prefabPath);
			foreach (string reference in references) {
				if (reference == targetPath) {
					results.Add(prefabPath);
					break;
				}
			}
		}
		return results.ToArray();
	}

	private static string[] GetAssetPaths(string dirPath, string filter) {
		string[] assertPaths = Directory.GetFiles(Application.dataPath + dirPath, filter, SearchOption.AllDirectories);
		for(int i = 0; i < assertPaths.Length; ++i) {
			assertPaths[i] = assertPaths[i].Replace("\\", "/");
			assertPaths[i] = assertPaths[i].Substring(assertPaths[i].IndexOf("Asset"));
		}
		return assertPaths;
	}
}
