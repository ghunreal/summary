﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.Editor.Utils
{
    public class SelectableList<T>
    {
        private List<SelectableListItem<T>> items;
        private Filter rootFilter = null;

        public SelectableListItem<T> AddItem(string name, T refObj, string filterName = null)
        {
            SelectableListItem<T> newItem = new SelectableListItem<T>(name, refObj);
            if(filterName != null && filterName != "")
            {
                Filter filter = FindFilterByName(filterName);
                if(filter == null)
                {
                    filter = AddFilter(filterName);
                }
                if(filter != null)
                {
                    filter.AddChild(newItem);
                }
            }
            return newItem;
        }
        public bool AddItemList(Dictionary<string, T> dictionary, string filterName = null)
        {
            foreach (KeyValuePair<string, T> pair in dictionary)
            {
                AddItem(pair.Key, pair.Value, filterName);
            }
            return true;
        }
        public bool RemoveItemByName(string name)
        {
            SelectableListItem<T> found = FindItemByName(name);
            if(found != null && rootFilter != null)
            {
                rootFilter.RemoveChildHierarchically(found);
            }
            return true;
        }
        public SelectableListItem<T> FindItemByName(string name)
        {
            SelectableListItem<T> found = null;
            foreach (SelectableListItem<T> item in items)
            {
                if(item.Name == name)
                {
                    found = item;
                    break;
                }
            }
            return found;
        }
        public Filter FindFilterByName(string name)
        {
            Filter filter = null;
            if (rootFilter != null)
            {
                SelectableListItem listItem = rootFilter.FindChildByNameHierarchically(name);
                if (listItem != null && typeof(Filter).IsInstanceOfType(listItem))
                {
                    filter = listItem as Filter;
                }
            }
            return filter;
        }
        public Filter AddFilter(string name, Filter parent = null)
        {
            if(rootFilter == null)
            {
                rootFilter = new Filter("");
            }
            if(parent == null)
            {
                parent = rootFilter;
            }
            Filter filter = new Filter(name);
            if(parent != null && filter != null)
            {
                if(!parent.AddChild(filter))
                {
                    filter = null;
                }
            }
            return filter;
        }
    }
}
