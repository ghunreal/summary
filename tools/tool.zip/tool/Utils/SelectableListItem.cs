﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.Editor.Utils
{
    public abstract class SelectableListItem
    {
        protected string name = "";

        public SelectableListItem(string inName)
        {
            name = inName;
        }
        public string Name
        {
            get
            {
                return name;
            }
        }

        virtual public bool AddChild(SelectableListItem item)
        {
            return false;
        }
        virtual public bool RemoveChild(SelectableListItem item)
        {
            return false;
        }
        virtual public bool RemoveChildHierarchically(SelectableListItem item)
        {
            return false;
        }
        virtual public SelectableListItem FindChildByNameHierarchically(string name)
        {
            return null;
        }
        virtual public SelectableListItem FindChildByName(string name)
        {
            return null;
        }
    }
    public class SelectableListItem<T> : SelectableListItem
    {
        protected T refObj;

        public SelectableListItem(string inName, T inRefObj) : base(inName)
        {
            refObj = inRefObj;
        }
        public T RefObj
        {
            get
            {
                return refObj;
            }
        }
    }

    public class Filter : SelectableListItem
    {
        private List<SelectableListItem> listChildren;
        public Filter(string inName) : base(inName)
        {
        }

        public override bool AddChild(SelectableListItem item)
        {
            if (listChildren.Contains(item))
                return false;
            listChildren.Add(item);
            return true;
        }
        public override bool RemoveChild(SelectableListItem item)
        {
            bool bSuccess = true;
            while (listChildren.Contains(item))
            {
                bSuccess = listChildren.Remove(item);
            }
            return true;
        }
        public override bool RemoveChildHierarchically(SelectableListItem item)
        {
            bool bSuccess = RemoveChild(item);
            if(!bSuccess)
            {
                foreach (SelectableListItem child in listChildren)
                {
                    if (child.RemoveChildHierarchically(item))
                    {
                        bSuccess = true;
                        break;
                    }
                }
            }
            return bSuccess;
        }
        public override SelectableListItem FindChildByNameHierarchically(string name)
        {
            SelectableListItem found = FindChildByName(name);
            if (found == null)
            {
                foreach (SelectableListItem child in listChildren)
                {
                    found = child.FindChildByNameHierarchically(name);
                    if (found != null)
                    {
                        break;
                    }
                }
            }
            return found;
        }
        public override SelectableListItem FindChildByName(string name)
        {
            SelectableListItem found = null;
            foreach (SelectableListItem child in listChildren)
            {
                if (child.Name == name)
                {
                    found = child;
                    break;
                }
            }
            return found;
        }
    }
}
