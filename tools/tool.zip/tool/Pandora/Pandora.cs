﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class Pandora
{
    [MenuItem("Pandora/Check Shader")]
    public static void CheckShader()
    {
        EditorWindow.GetWindow<ShaderChecker>().position = new Rect(50, 50, 850, 1000);
    }

    [MenuItem("Pandora/Check Model")]
    public static void CheckModel()
    {
        EditorWindow.GetWindow<ModelChecker>().position = new Rect(50, 50, 850, 1000);
    }

    [MenuItem("Pandora/Check Material")]
    public static void CheckMaterial()
    {
        EditorWindow.GetWindow<MaterialChecker>().position = new Rect(50, 50, 850, 1000);
    }

    [MenuItem("Pandora/Check Useless UI")]
    public static void CheckUseless()
    {
        EditorWindow.GetWindow<UselessChecker>().position = new Rect(50, 50, 850, 1000);
    }

    [MenuItem("Pandora/希望")]
    public static void Hope()
    {
        EditorUtility.DisplayDialog("希望", "是否格式化所有硬盘，一旦确定就无法恢复！", "确定");
    }
}
