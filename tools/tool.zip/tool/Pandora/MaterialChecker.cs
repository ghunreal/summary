﻿using UnityEngine;
using UnityEditor;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public class MaterialChecker : EditorWindow
{
    Dictionary<Material, List<Material>> errors = new Dictionary<Material, List<Material>>();
    int errorCount = 0;

    void OnEnable()
    {
        errors.Clear();
        errorCount = 0;

        Dictionary<string, List<Material>> mtrls = new Dictionary<string, List<Material>>();
        var assets = AssetDatabase.FindAssets("t:Material");
        foreach (string guid in assets)
        {
            Material mtrl = AssetDatabase.LoadAssetAtPath<Material>(AssetDatabase.GUIDToAssetPath(guid));
            List<Material> temp;
            if (!mtrls.TryGetValue(mtrl.shader.name, out temp))
            {
                temp = new List<Material>();
                mtrls.Add(mtrl.shader.name, temp);
            }
            temp.Add(mtrl);
        }

        int count = 0;
        List<Material> removes = new List<Material>();
        StringBuilder sb = new StringBuilder(512);
        var iter = mtrls.GetEnumerator();
        while (iter.MoveNext())
        {
            while (iter.Current.Value.Count > 0)
            {
                for (int i = 1; i < iter.Current.Value.Count; ++i)
                {
                    if (IsSame(iter.Current.Value[0], iter.Current.Value[i]))
                    {
                        removes.Add(iter.Current.Value[i]);
                    }
                }
                removes.Add(iter.Current.Value[0]);

                if (removes.Count > 1)
                {
                    errors.Add(removes[0], new List<Material>(removes));
                    errorCount += removes.Count;
                }

                count += removes.Count;
                sb.Remove(0, sb.Length);
                sb.AppendFormat("{0}/{1}", count, assets.Length);
                EditorUtility.DisplayProgressBar("Checking...", sb.ToString(), (float)(count + 1) / assets.Length);

                removes.ForEach((x) => iter.Current.Value.Remove(x));
                removes.Clear();
            }
        }
        EditorUtility.ClearProgressBar();
    }

    void OnDisable()
    {
        errors.Clear();
        errorCount = 0;
    }

    Vector2 scrollPos;
    void OnGUI()
    {
        GUILayout.Label("重复材质检测", EditorStyles.boldLabel);
        GUILayout.Label(string.Format("数量: {0}", errorCount));
        GUILayout.Label("第一次查找引用会非常慢！！！", EditorStyles.boldLabel);

        scrollPos = GUILayout.BeginScrollView(scrollPos);
        var iter = errors.GetEnumerator();
        while (iter.MoveNext())
        {
            if (iter.Current.Value.Count == 0)
                continue;

            GUILayout.Label("-----------------------------------------------------------------------------------------------------------------------------------------------------------");
            iter.Current.Value.ForEach((x) =>
            {
                GUILayout.BeginHorizontal();
                GUILayout.Label(AssetDatabase.GetAssetPath(x), EditorStyles.boldLabel, GUILayout.Width(700));
                if (GUILayout.Button("选中", GUILayout.MaxWidth(75))) Selection.activeObject = x;
                if (GUILayout.Button("引用", GUILayout.MaxWidth(75))) FindReferences(x);
                GUILayout.EndHorizontal();
            });
        }
        GUILayout.EndScrollView();
    }

    void FindReferences(Object obj)
    {
        if (BuildAssetBundles.allDeps.Count == 0)
            BuildAssetBundles.RebuildDatabase("t:Prefab");

        List<string> refs;
        if (BuildAssetBundles.allDeps.TryGetValue(AssetDatabase.GetAssetPath(obj), out refs))
        {
            Object[] objs = new Object[refs.Count];
            for (int i = 0; i < refs.Count; ++i)
            {
                objs[i] = AssetDatabase.LoadAssetAtPath<Object>(refs[i]);
            }
            Selection.objects = objs;
        }
    }

    bool IsSame(Material a, Material b)
    {
        if (a.shader.name != b.shader.name)
            return false;

        int count = ShaderUtil.GetPropertyCount(a.shader);
        for (int i = 0; i < count; ++i)
        {
            string name = ShaderUtil.GetPropertyName(a.shader, i);
            switch (ShaderUtil.GetPropertyType(a.shader, i))
            {
                case ShaderUtil.ShaderPropertyType.Color:
                    if (a.GetColor(name) != b.GetColor(name))
                        return false;
                    break;

                case ShaderUtil.ShaderPropertyType.Float:
                    if (a.GetFloat(name) != b.GetFloat(name))
                        return false;
                    break;

                case ShaderUtil.ShaderPropertyType.Range:
                    if (a.GetInt(name) != b.GetInt(name))
                        return false;
                    break;

                case ShaderUtil.ShaderPropertyType.TexEnv:
                    if (name != "_CameraDepthTexture")
                    {
                        if (a.GetTexture(name) != b.GetTexture(name))
                            return false;
                        if (a.GetTextureOffset(name) != b.GetTextureOffset(name))
                            return false;
                        if (a.GetTextureScale(name) != b.GetTextureScale(name))
                            return false;
                    }
                    break;

                case ShaderUtil.ShaderPropertyType.Vector:
                    if (a.GetVector(name) != b.GetVector(name))
                        return false;
                    break;

                default:
                    break;
            }
        }

        return true;
    }
}
