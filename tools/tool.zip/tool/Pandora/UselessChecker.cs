﻿using UnityEngine;
using UnityEditor;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public class UselessChecker : EditorWindow
{
    List<Sprite> useless = new List<Sprite>();

    void OnEnable()
    {
        useless.Clear();
        StringBuilder sb = new StringBuilder(512);

        Dictionary<string, HashSet<string>> results = new Dictionary<string, HashSet<string>>();
        string[] prefabs = AssetDatabase.FindAssets("t:Prefab", new string[] { "Assets/Resources/Prefabs" });
        for (int i = 0; i < prefabs.Length; ++i)
        {
            string guid = prefabs[i];
            sb.Remove(0, sb.Length);
            sb.AppendFormat("{0}/{1}", i + 1, prefabs.Length);
            EditorUtility.DisplayProgressBar("Checking...", sb.ToString(), (float)(i + 1) / prefabs.Length);

            string[] references = AssetDatabase.GetDependencies(AssetDatabase.GUIDToAssetPath(guid));
            foreach (string reference in references)
            {
                HashSet<string> allReferenced;
                if (!results.TryGetValue(reference, out allReferenced))
                {
                    allReferenced = new HashSet<string>();
                    results.Add(reference, allReferenced);
                }
                allReferenced.Add(AssetDatabase.GUIDToAssetPath(guid));
            }
        }

        string[] sprites = AssetDatabase.FindAssets("t:Sprite", new string[] { "Assets/Content/UI" });
        foreach (string guid in sprites)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            if (path.StartsWith("Assets/Content/UI/BG"))
                continue;
            if (!results.ContainsKey(path))
                useless.Add(AssetDatabase.LoadAssetAtPath<Sprite>(path));
        }
        EditorUtility.ClearProgressBar();
    }

    void OnDisable()
    {
        useless.Clear();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    List<Sprite> removes = new List<Sprite>();
    Vector2 scrollPos;
    void OnGUI()
    {
        GUILayout.Label("无用UI资源", EditorStyles.boldLabel);
        GUILayout.Label(string.Format("数量: {0}", useless.Count), EditorStyles.boldLabel);
        if (GUILayout.Button("一键删除"))
        {
            useless.ForEach((x) => { AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(x)); });
            useless.Clear();
        }

        scrollPos = GUILayout.BeginScrollView(scrollPos);
        foreach (var obj in useless)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(AssetDatabase.GetAssetPath(obj), EditorStyles.boldLabel, GUILayout.Width(500));
            if (GUILayout.Button("选中", GUILayout.MaxWidth(75))) Selection.activeObject = obj;
            if (GUILayout.Button("删除", GUILayout.MaxWidth(75)))
            {
                AssetDatabase.DeleteAsset(AssetDatabase.GetAssetPath(obj));
                removes.Add(obj);
            }
            GUILayout.EndHorizontal();
        }
        GUILayout.EndScrollView();

        removes.ForEach((x) => { useless.Remove(x); });
        removes.Clear();
    }
}
