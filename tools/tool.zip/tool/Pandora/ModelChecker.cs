﻿using UnityEngine;
using UnityEditor;
using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public class ModelChecker : EditorWindow
{
    static List<string> prefix = new List<string>()
    {
        "Hero",
        "Npc",
        "UI",
        "S_",
    };

    List<KeyValuePair<GameObject, ModelImporter>> invalids = new List<KeyValuePair<GameObject, ModelImporter>>();
    List<KeyValuePair<GameObject, ModelImporter>> norenderers = new List<KeyValuePair<GameObject, ModelImporter>>();
    List<KeyValuePair<GameObject, ModelImporter>> nomaterials = new List<KeyValuePair<GameObject, ModelImporter>>();
    List<KeyValuePair<GameObject, ModelImporter>> standards = new List<KeyValuePair<GameObject, ModelImporter>>();

    void OnEnable()
    {
        invalids.Clear();
        norenderers.Clear();
        nomaterials.Clear();
        standards.Clear();

        StringBuilder sb = new StringBuilder(256);
        var assets = AssetDatabase.FindAssets("t:Model");
        for (int i = 0; i < assets.Length; ++i)
        {
            sb.Remove(0, sb.Length);
            sb.AppendFormat("{0}/{1}", i + 1, assets.Length);
            EditorUtility.DisplayProgressBar("Checking...", sb.ToString(), (float)(i + 1) / assets.Length);

            GameObject mesh = AssetDatabase.LoadAssetAtPath<GameObject>(AssetDatabase.GUIDToAssetPath(assets[i]));
            Renderer renderer = mesh.GetComponent<Renderer>();
            if (renderer == null)
            {
                if(!mesh.name.StartsWith("Hero") && !mesh.name.StartsWith("Npc"))
                    AddToList(norenderers, mesh, assets[i]);
            }
            else if (renderer.sharedMaterial == null)
            {
                if(!mesh.name.StartsWith("Hero") && !mesh.name.StartsWith("Npc"))
                    AddToList(nomaterials, mesh, assets[i]);
            }
            else
            {
                bool hasNormal = false;
                foreach (var mtrl in renderer.sharedMaterials)
                {
                    if (mtrl.shader.name == "Standard")
                    {
                        AddToList(standards, mesh, assets[i]);
                        hasNormal = true;
                        break;
                    }
                    else if (mtrl.HasProperty("_NormalMap") || mtrl.HasProperty("_CubeMap"))
                    {
                        hasNormal = true;
                        break;
                    }
                }
                if (!hasNormal)
                    AddToList(invalids, mesh, assets[i]);
            }
        }
        EditorUtility.ClearProgressBar();
    }

    void OnDisable()
    {
        invalids.Clear();
        norenderers.Clear();
        nomaterials.Clear();
        standards.Clear();

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    Vector2 scrollPos;
    void OnGUI()
    {
        GUILayout.Label("法线导入检测", EditorStyles.boldLabel);
        GUILayout.Label(string.Format("数量: {0}", invalids.Count + norenderers.Count + nomaterials.Count));

        Color old = GUI.color;
        GUI.color = Color.red;
        if (GUILayout.Button("一键修复（我相信你会谨慎的使用自己强大的力量，但是真正的胜利，是激励人民的心）")) FixAll();
        GUI.color = old;

        scrollPos = GUILayout.BeginScrollView(scrollPos);
        norenderers.ForEach((x) => { ListAll(x, "没有Renderer无法判断"); });
        nomaterials.ForEach((x) => { ListAll(x, "没有Material无法判断"); });
        invalids.ForEach((x) => { ListAll(x, "材质没有用到法线"); });
        standards.ForEach((x) => { ListAll(x, "使用了标准材质"); });
        GUILayout.EndScrollView();
    }

    void AddToList(List<KeyValuePair<GameObject, ModelImporter>> target, GameObject go, string guid)
    {
        ModelImporter importer = ModelImporter.GetAtPath(AssetDatabase.GUIDToAssetPath(guid)) as ModelImporter;
        if (importer != null && importer.importNormals != ModelImporterNormals.None)
            target.Add(new KeyValuePair<GameObject, ModelImporter>(go, importer));
    }

    void ListAll(KeyValuePair<GameObject, ModelImporter> iter, string msg)
    {
        GameObject go = iter.Key;
        ModelImporter importer = iter.Value;
        if (importer.importNormals == ModelImporterNormals.None)
            return;

        GUILayout.BeginHorizontal();
        GUILayout.Label(go.name, EditorStyles.boldLabel, GUILayout.Width(300));
        Color old = GUI.color;
        GUI.color = Color.red;
        GUILayout.Label(msg, EditorStyles.boldLabel, GUILayout.Width(300));
        GUI.color = old;
        if (GUILayout.Button("选中", GUILayout.MaxWidth(75))) Select(go);
        if (GUILayout.Button("修复", GUILayout.MaxWidth(75))) Fix(importer);
        GUILayout.EndHorizontal();
    }

    void Select(GameObject go)
    {
        Selection.activeObject = go;
    }

    void Fix(ModelImporter importer)
    {
        importer.importNormals = ModelImporterNormals.None;
        importer.SaveAndReimport();
    }

    void FixAll()
    {
        norenderers.ForEach((x) => { Fix(x.Value); });
        nomaterials.ForEach((x) => { Fix(x.Value); });
        standards.ForEach((x) => { Fix(x.Value); });
        invalids.ForEach((x) => { Fix(x.Value); });
    }
}
