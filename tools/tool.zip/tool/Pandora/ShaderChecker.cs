﻿using UnityEngine;
using UnityEditor;
using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public class ShaderChecker : EditorWindow
{
    Dictionary<string, Action<Material>> shaders = new Dictionary<string, Action<Material>>()
    {
        { "Particles/Additive", (x) => { ReplaceAdditive(x); } },
        { "Particles/Alpha Blended", (x) => { ReplaceAlphaBlended(x); } },
    };

    List<Material> mtrls = new List<Material>();
    void OnEnable()
    {
        mtrls.Clear();
        var assets = AssetDatabase.FindAssets("t:Material");
        StringBuilder sb = new StringBuilder(256);
        for (int i = 0; i < assets.Length; ++i)
        {
            sb.Remove(0, sb.Length);
            sb.AppendFormat("{0}/{1}", i + 1, assets.Length);
            EditorUtility.DisplayProgressBar("Checking...", sb.ToString(), (float)(i + 1) / assets.Length);
            Material mtrl = AssetDatabase.LoadAssetAtPath<Material>(AssetDatabase.GUIDToAssetPath(assets[i]));
            if (shaders.ContainsKey(mtrl.shader.name))
                mtrls.Add(mtrl);
        }
        EditorUtility.ClearProgressBar();
    }

    void OnDisable()
    {
        mtrls.Clear();
    }

    Vector2 scrollPos;
    StringBuilder builder = new StringBuilder(1024);
    void OnGUI()
    {
        GUILayout.Label("使用了会在移动端影响性能的shader", EditorStyles.boldLabel);
        GUILayout.Label(string.Format("数量: {0}", mtrls.Count));
        if (GUILayout.Button("一键替换"))
            ReplaceAll();

        scrollPos = GUILayout.BeginScrollView(scrollPos);
        foreach (var mtrl in mtrls)
        {
            GUILayout.BeginHorizontal();

            builder.Remove(0, builder.Length);
            builder.AppendFormat("[Material] {0}", mtrl.name);
            GUILayout.Label(builder.ToString(), EditorStyles.boldLabel, GUILayout.Width(300));

            builder.Remove(0, builder.Length);
            builder.AppendFormat("[Shader] {0}", mtrl.shader.name);
            GUILayout.Label(builder.ToString(), EditorStyles.boldLabel, GUILayout.Width(300));

            Color old = GUI.color;
            GUI.color = mtrl.GetColor("_TintColor");
            GUILayout.Box("  ", GUILayout.MaxWidth(75));
            GUI.color = old;

            if (GUILayout.Button("选中", GUILayout.MaxWidth(75))) Selection.activeObject = mtrl;
            if (GUILayout.Button("替换", GUILayout.MaxWidth(75))) Replace(mtrl);
            GUILayout.EndHorizontal();
        }
        GUILayout.EndScrollView();
    }

    void Replace(Material mtrl)
    {
        Action<Material> act;
        if (shaders.TryGetValue(mtrl.shader.name, out act))
            act(mtrl);
        mtrls.Remove(mtrl);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    void ReplaceAll()
    {
        foreach (var mtrl in mtrls)
        {
            Action<Material> act;
            if (shaders.TryGetValue(mtrl.shader.name, out act))
                act(mtrl);
        }
        mtrls.Clear();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    static void ReplaceAdditive(Material mtrl)
    {
        Color color = mtrl.GetColor("_TintColor");
        if (color == Color.white)
            mtrl.shader = Shader.Find("Mobile/Particles/Additive");
        else
            mtrl.shader = Shader.Find("Mobile/Particles/AdditiveColor");
    }

    static void ReplaceAlphaBlended(Material mtrl)
    {
        Color color = mtrl.GetColor("_TintColor");
        if (color == Color.white)
            mtrl.shader = Shader.Find("Mobile/Particles/Alpha Blended Color");
        else
            mtrl.shader = Shader.Find("Mobile/Particles/Alpha Blended Color");
    }
}
