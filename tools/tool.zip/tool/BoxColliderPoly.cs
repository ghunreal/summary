﻿using UnityEngine;
using UnityEditor;
using System.Collections;

[CustomEditor(typeof(BoxCollider))]
[CanEditMultipleObjects]
public class BoxColliderPoly : Editor
{
	#region private member
	private static bool box = false;
	private Vector3[] points = new Vector3[8];
	private Color pc = new Color(0, 0, 0, 0.2f);
	private Color lc = new Color(0, 0, 0, 0);
	private BoxCollider c;
	#endregion private member

	#region editor callbacks
	public override void OnInspectorGUI()
	{
		base.OnInspectorGUI();
		box = EditorGUILayout.Toggle("Draw surface", box);
		if (GUI.changed)
			EditorUtility.SetDirty(target);

		return;
	}
	#endregion editor callbacks

	#region editor event
	private void OnSceneGUI()
	{
		if (!box)
			return;

		c = (BoxCollider)target;

		// get origin vectors
		points[0] = - c.size / 2;
		points[1] = new Vector3(c.size.x / 2, -c.size.y / 2, -c.size.z / 2);
		points[2] = new Vector3(c.size.x / 2, -c.size.y / 2, c.size.z / 2);
		points[3] = new Vector3(-c.size.x / 2, -c.size.y / 2, c.size.z / 2);
		points[4] = c.size / 2;
		points[5] = new Vector3(-c.size.x / 2, c.size.y / 2, c.size.z / 2);
		points[6] = new Vector3(-c.size.x / 2, c.size.y / 2, -c.size.z / 2);
		points[7] = new Vector3(c.size.x / 2, c.size.y / 2, -c.size.z / 2);

		// get rotation
		Quaternion q = c.transform.rotation;
		Vector3 p = c.transform.position;

		// rotate vectors
		for (int i = 0; i < 8; ++i) {
			Vector3 temp = points[i] + c.center;
			temp.x *= c.transform.localScale.x;
			temp.y *= c.transform.localScale.y;
			temp.z *= c.transform.localScale.z;
			points[i] = q * temp + p;
		}

		Handles.DrawSolidRectangleWithOutline(new Vector3[]{points[0], points[1], points[2], points[3]}, pc, lc);
		Handles.DrawSolidRectangleWithOutline(new Vector3[]{points[4], points[5], points[6], points[7]}, pc, lc);
		Handles.DrawSolidRectangleWithOutline(new Vector3[]{points[0], points[1], points[7], points[6]}, pc, lc);
		Handles.DrawSolidRectangleWithOutline(new Vector3[]{points[1], points[2], points[4], points[7]}, pc, lc);
		Handles.DrawSolidRectangleWithOutline(new Vector3[]{points[4], points[5], points[3], points[2]}, pc, lc);
		Handles.DrawSolidRectangleWithOutline(new Vector3[]{points[3], points[0], points[6], points[5]}, pc, lc);

		return;
	}
	#endregion editor event
}
