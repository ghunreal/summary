﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

public class PrefabApply : EditorWindow {
    public class ProtypeEntry
    {
        public GameObject protype;
        public bool selected;
    }

    private Transform container;
    private List<ProtypeEntry> protypes = new List<ProtypeEntry>();
    private Object[] prefabs;

    [MenuItem("Custom/Prefab Apply")]
    public static void ShowWindow()
    {
        EditorWindow.GetWindow(typeof(PrefabApply));
    }

    void OnGUI()
    {
        GUILayout.Label("Prefabs", EditorStyles.boldLabel);
        if (GUILayout.Button("Select All", EditorStyles.miniButtonMid))
        {
            foreach (ProtypeEntry entry in protypes)
            {
                entry.selected = true;
            }
        }
        if (GUILayout.Button("Unselect All", EditorStyles.miniButtonMid))
        {
            foreach (ProtypeEntry entry in protypes)
            {
                entry.selected = false;
            }
        }

        foreach (ProtypeEntry entry in protypes)
        {
            entry.selected = GUILayout.Toggle(entry.selected, entry.protype.name);
        }

        if (GUILayout.Button("Replace", EditorStyles.miniButtonMid))
        {
            Replace();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }
    }

    void OnEnable()
    {
        container = GameObject.Find("UI/UICanvas/WindowLayer").transform;

        Refresh();
    }

    void Refresh()
    {
        prefabs = Resources.LoadAll("prefabs/UI");

        protypes.Clear();
        foreach (Object obj in Resources.LoadAll("prefabs/UI/Controller"))
        {
            protypes.Add(new ProtypeEntry { protype = obj as GameObject, selected = false });
        }
    }

    void Replace()
    {
        foreach (ProtypeEntry entry in protypes)
        {
            if (!entry.selected)
                continue;

            foreach (Object obj in prefabs)
            {
                GameObject go = obj as GameObject;
                if (go == null || entry.protype == go)
                    continue;

                go = PrefabUtility.InstantiatePrefab(obj) as GameObject;
                go.transform.SetParent(container, false);

                bool result = false;
                Replace(go, entry.protype, ref result);
                DestroyImmediate(go);
            }
        }

        Refresh();
    }

    void Replace(GameObject go, GameObject prefab, ref bool result)
    {
        int childCount = go.transform.childCount;
        for (int i = childCount - 1; i >= 0; --i)
        {
            GameObject child = go.transform.GetChild(i).gameObject;
            if (IsPrefab(child, prefab))
            {
                // Copy component and name
                string oldName = child.name;
                UnityEditorInternal.ComponentUtility.CopyComponent(child.GetComponent<RectTransform>());

                // Destroy old
                DestroyImmediate(child);

                // Create new
                child = PrefabUtility.InstantiatePrefab(prefab) as GameObject;
                child.name = oldName;
                child.transform.SetParent(go.transform, false);
                UnityEditorInternal.ComponentUtility.PasteComponentValues(child.GetComponent<RectTransform>());

                result = true;
            }

            Replace(child, prefab, ref result);
        }
    }

    bool IsPrefab(GameObject go, GameObject prefab)
    {
        LuaBehavior prefabLua = prefab.GetComponent<LuaBehavior>();
        if (prefabLua != null)
        {
            LuaBehavior goLua = go.GetComponent<LuaBehavior>();
            if (goLua == null)
                return false;
            else
                return prefabLua.filename == goLua.filename;
        }
        else
        {
            return go.GetComponent(prefab.name) != null;
        }
    }
}
