﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class ClearPlayerPrefs
{
	[MenuItem("Tools/Clear PlayerPrefs")]
	public static void Clear()
	{
		PlayerPrefs.DeleteAll();
	}
}
