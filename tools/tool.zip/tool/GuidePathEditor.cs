﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

[CustomEditor(typeof(GuidePath))]
public class GuidePathEditor : Editor
{
    void OnEnable()
    {
        GuidePath path = target as GuidePath;
        path.Rebuild();
        SceneView.onSceneGUIDelegate += CustomSceneGUI;
    }

    void OnDisable()
    {
        SceneView.onSceneGUIDelegate -= CustomSceneGUI;
    }

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        GuidePath path = target as GuidePath;
        if (path.points != null)
            GUILayout.Label("Size = " + path.points.Length);
        if (GUILayout.Button("Add"))
        {
            if (path.points == null || path.points.Length == 0)
            {
                path.points = new Vector3[1];
                path.points[0] = path.transform.position;
            }
            else
            {
                Vector3[] points = new Vector3[path.points.Length + 1];
                for (int i = 0; i < path.points.Length; ++i)
                {
                    points[i] = path.points[i];
                }
                points[path.points.Length] = points[path.points.Length - 1] + GetForward(path.points.Length - 1) * 10.0f;
                path.points = points;
            }
            Repaint();
        }
        if (GUILayout.Button("Clear"))
        {
            path.points = null;
        }
    }

    void CustomSceneGUI(SceneView sceneView)
    {
        GuidePath path = target as GuidePath;
        if (path.points == null || path.points.Length < 2)
            return;

        for (int i = 0; i < path.points.Length; ++i)
        {
            Quaternion rot = Quaternion.FromToRotation(Vector3.right, GetForward(i));
            Vector3 newPos = Handles.FreeMoveHandle(path.points[i], rot, 0.5f, Vector3.zero, Handles.RectangleCap);
            newPos.y = path.transform.localPosition.y;
            if (newPos != path.points[i])
            {
                path.points[i] = newPos;
                path.Rebuild();
            }
        }

    }

    Vector3 GetForward(int index)
    {
        GuidePath path = target as GuidePath;

        if (index == 0)
            return path.transform.forward;

        Vector3 p0 = path.points[index - 1];
        Vector3 p1 = path.points[index];
        return (p1 - p0).normalized;
    }
}
