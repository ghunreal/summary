using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Callbacks;
using UnityEditor.XCodeEditor;
using UnityEditor.iOS.Xcode;
#endif
using System.IO;

public static class XCodePostProcess
{

#if UNITY_EDITOR
	[PostProcessBuild(999)]
	public static void OnPostProcessBuild( BuildTarget target, string pathToBuiltProject )
	{
		if (target != BuildTarget.iOS) {
			Debug.LogWarning("Target is not iPhone. XCodePostProcess will not run");
			return;
		}

		// Create a new project object from build target
		XCProject project = new XCProject( pathToBuiltProject );

		// Find and run through all projmods files to patch the project.
		// Please pay attention that ALL projmods files in your project folder will be excuted!
		string[] files = Directory.GetFiles( Application.dataPath, "*.projmods", SearchOption.AllDirectories );
		foreach( string file in files ) {
			UnityEngine.Debug.Log("ProjMod File: "+file);
			project.ApplyMod( file );
		}

		//TODO implement generic settings as a module option
        project.overwriteBuildSetting("ENABLE_BITCODE", "No", "Debug");
        project.overwriteBuildSetting("ENABLE_BITCODE", "No", "Release");
		project.overwriteBuildSetting("GCC_ENABLE_CPP_RTTI", "YES", "Debug");
		project.overwriteBuildSetting("GCC_ENABLE_CPP_EXCEPTIONS", "YES", "Debug");
		project.overwriteBuildSetting("GCC_ENABLE_OBJC_EXCEPTIONS", "YES", "Debug");
        project.overwriteBuildSetting("DEBUG_INFORMATION_FORMAT", "DWARF with dSYM File", "Debug");

		// Finally save the xcode project
		project.Save();

        ChangePlist(pathToBuiltProject);
	}

    private static void ChangePlist(string pathToBuiltProject)
    {
        string plistPath = pathToBuiltProject + "/Info.plist";
        PlistDocument plist = new PlistDocument();
        plist.ReadFromString(File.ReadAllText(plistPath));

        PlistElementDict rootDict = plist.root;
        rootDict.SetString("NSCameraUsageDescription", "是否允许此App使用你的相机？");
        rootDict.SetString("NSMicrophoneUsageDescription", "是否允许此App使用你的麦克风？");

        File.WriteAllText(plistPath, plist.WriteToString());
    }
#endif

	public static void Log(string message)
	{
		UnityEngine.Debug.Log("PostProcess: "+message);
	}
}
