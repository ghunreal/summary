﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;

[CustomEditor(typeof(CameraFollow))]
public class CameraVisibility : Editor {
    List<Vector3> intersectPoints = new List<Vector3>();
    Vector3[] aabb = new Vector3[4];

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        float width, height;
        GetWidthHeight(out width, out height);

        GUILayout.Label("Visibility", EditorStyles.boldLabel);
        GUILayout.Label(string.Format("width = {0}", width));
        GUILayout.Label(string.Format("height = {0}", height));

        if (GUILayout.Button("Near", EditorStyles.miniButtonMid))
        {
            CameraFollow camera = target as CameraFollow;
            camera.SetOffset(camera.nearOffset - camera.oldOff);
        }
        if (GUILayout.Button("Normal", EditorStyles.miniButtonMid))
        {
            CameraFollow camera = target as CameraFollow;
            camera.SetOffset(camera.normalOffset - camera.oldOff);
        }
        if (GUILayout.Button("Far", EditorStyles.miniButtonMid))
        {
            CameraFollow camera = target as CameraFollow;
            camera.SetOffset(camera.farOffset - camera.oldOff);
        }
    }

    void GetWidthHeight(out float width, out float height)
    {
        Camera camera = (target as CameraFollow).GetComponent<Camera>();
        Plane ground = new Plane(Vector3.up, Vector3.zero);

        // 计算截头锥于地面的交点
        intersectPoints.Clear();
        intersectPoints.Add(GetIntersectPoint(camera.ViewportPointToRay(new Vector3(0.0f, 0.0f, 1.0f)), ground)); // 左下
        intersectPoints.Add(GetIntersectPoint(camera.ViewportPointToRay(new Vector3(0.0f, 1.0f, 1.0f)), ground)); // 左上
        intersectPoints.Add(GetIntersectPoint(camera.ViewportPointToRay(new Vector3(1.0f, 1.0f, 1.0f)), ground)); // 右上
        intersectPoints.Add(GetIntersectPoint(camera.ViewportPointToRay(new Vector3(1.0f, 0.0f, 1.0f)), ground)); // 右下

        // 计算交点四边形的AABB
        float minX = System.Single.MaxValue;
        float minZ = System.Single.MaxValue;
        float maxX = System.Single.MinValue;
        float maxZ = System.Single.MinValue;
        foreach (Vector3 p in intersectPoints)
        {
            if (p.x < minX) minX = p.x;
            if (p.z < minZ) minZ = p.z;
            if (p.x > maxX) maxX = p.x;
            if (p.z > maxZ) maxZ = p.z;
        }

        // 计算AABB的四个点
        aabb[0] = new Vector3(minX, 0.0f, minZ); // 左下
        aabb[1] = new Vector3(minX, 0.0f, maxZ); // 左上
        aabb[2] = new Vector3(maxX, 0.0f, maxZ); // 右上
        aabb[3] = new Vector3(maxX, 0.0f, minZ); // 右下

        // 计算宽高
        width = maxX - minX;
        height = maxZ - minZ;
    }

    Vector3 GetIntersectPoint(Ray ray, Plane plane)
    {
        float distance;
        plane.Raycast(ray, out distance);
        return ray.origin + ray.direction * distance;
    }

    void CustomSceneGUI(SceneView sceneView)
    {
        // Draw points of intersection
        if (intersectPoints.Count == 4)
        {
            Handles.color = Color.green;
            Handles.DrawLine(intersectPoints[0], intersectPoints[1]);
            Handles.DrawLine(intersectPoints[1], intersectPoints[2]);
            Handles.DrawLine(intersectPoints[2], intersectPoints[3]);
            Handles.DrawLine(intersectPoints[3], intersectPoints[0]);
        }

        // Draw AABB
        Handles.color = Color.red;
        Handles.DrawLine(aabb[0], aabb[1]);
        Handles.DrawLine(aabb[1], aabb[2]);
        Handles.DrawLine(aabb[2], aabb[3]);
        Handles.DrawLine(aabb[3], aabb[0]);
    }

    void OnEnable()
    {
        SceneView.onSceneGUIDelegate += CustomSceneGUI;
    }

    void OnDisable()
    {
        SceneView.onSceneGUIDelegate -= CustomSceneGUI;
    }
}
