﻿using UnityEngine;
using UnityEditor;
using System.Collections;

[CustomEditor(typeof(UISortingLayer))]
public class UISortingLayerEditor : Editor {
    void OnEnable()
    {
        MeshRenderer[] mesh = (target as UISortingLayer).GetComponentsInChildren<MeshRenderer>();
        foreach (MeshRenderer r in mesh)
        {
            r.sortingLayerID = SortingLayer.NameToID("UI");
        }
    }
}
