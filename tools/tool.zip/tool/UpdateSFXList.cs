﻿using UnityEngine;
using UnityEditor;
using System.IO;
using System.Collections.Generic;

public class UpdateSFXList : EditorWindow
{
    static readonly string TEMP_PATH = "Assets/Temp/";
	#region MenuItem
	[MenuItem("Utility/UpdateSFXList")]
	public static void CreatePrefab()
	{
        if (Directory.Exists(TEMP_PATH))
            Directory.Delete(TEMP_PATH, true);
        Directory.CreateDirectory(TEMP_PATH);

        string[] guids = AssetDatabase.FindAssets("t:Prefab", new string[] { "Assets/Resources/Prefabs/SFX" });
        for (int i = 0; i < guids.Length; ++i) {
            string path = AssetDatabase.GUIDToAssetPath(guids[i]);
            GameObject go = AssetDatabase.LoadAssetAtPath(path, typeof(GameObject)) as GameObject;
            EditorUtility.DisplayProgressBar("Process SFX prefabs", string.Format("{0} {1}/{2}", go.name, i, guids.Length), (float)i / guids.Length);

            SFXController ctrl = go.GetComponent<SFXController>();
            if (ctrl != null)
                ctrl.Init();

            CreateNew(go, path);
        }
		EditorUtility.ClearProgressBar();

        Directory.Delete(TEMP_PATH, true);
        AssetDatabase.DeleteAsset(TEMP_PATH);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
	}

	static void CreateNew(GameObject go, string path)
	{
		string temp = TEMP_PATH + go.name + ".prefab";
		Object prefab = PrefabUtility.CreateEmptyPrefab(temp); // this will change the loaded assets;
		if (go != null)
			PrefabUtility.ReplacePrefab(go, prefab);//, ReplacePrefabOptions.ConnectToPrefab);
		AssetDatabase.MoveAsset(temp, path);

		return;
	}

	// [MenuItem("Utility/SFXUpdateSelection")]
	private static void UpdateSelection()
	{
		GameObject go = Selection.activeGameObject;
		string relativePath = AssetDatabase.GetAssetPath(go);
		if (!relativePath.Contains("SFX")) {
			EditorUtility.DisplayDialog("Update SFXList", "Not a SFX prefab. Nothing changed.", "OK");
			return;
		}

		// GameObject go = AssetDatabase.LoadAssetAtPath(relativePath, typeof(GameObject)) as GameObject;
		// EditorUtility.DisplayProgressBar("Process SFX prefabs", go.name + " " + i + "//" + files.Length, (float)i / files.Length);

		SFXController ctrl = go.GetComponent<SFXController>();
		if (ctrl == null)
			ctrl = go.AddComponent<SFXController>();
		//ctrl.Init();

		relativePath = relativePath.Replace("\\", "/");
		CreateNew(go, relativePath);
		EditorUtility.DisplayDialog("Update SFXList", "Done", "OK");

		return;
	}
	#endregion MenuItem	
}
