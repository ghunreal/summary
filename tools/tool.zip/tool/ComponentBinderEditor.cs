﻿using System;
using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.IO;


[CustomEditor(typeof(ComponentBinder))]
public class ComponentBinderEditor : Editor
{
    private static readonly string LUA_PATH = "Assets/Scripts/Slua/Resources/";
    private static readonly string COMPONENTS_START = "----------COMPONENTS BEGIN----------";
    private static readonly string COMPONENTS_END = "----------COMPONENTS END----------";

    private Vector2 scrollPos;
    private ComponentBinder binder;

    List<ComponentBinder.Entry> entries = new List<ComponentBinder.Entry>();

    void OnEnable()
    {
        binder = target as ComponentBinder;

        // 查找所有Component并保存在entries中
        entries.Clear();
        ComponentBinder.TravelComponents(binder.gameObject, (key, type, value, index) =>
        {
            entries.Add(new ComponentBinder.Entry(key, type, value, index));
        });
    }

    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        // 打印出所有查找到的Component
        GUILayout.Label("Preview", EditorStyles.boldLabel);
        scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.Height(150));
        foreach (ComponentBinder.Entry entry in entries)
        {
            if (entry.index == -1)
                GUILayout.Label(string.Format("{0} {1};", entry.type, entry.key), EditorStyles.label);
            else
                GUILayout.Label(string.Format("{0} {1}[{2}];", entry.type, entry.key, entry.index), EditorStyles.label);
        }
        GUILayout.EndScrollView();

        // 导出按钮，将查找到的Component信息赋值给ComponentBinder，并打印注释到相应的lua文件
        if (GUILayout.Button("Export", EditorStyles.miniButtonMid))
        {
            // 设置ComponentBinder
            binder.SetEntries(entries);

	        GameObject selectGO = Selection.activeGameObject;
	        PrefabType selectPrefabType = PrefabUtility.GetPrefabType(selectGO);
	        if (selectPrefabType == PrefabType.PrefabInstance) {
				UnityEngine.Object prefabAsset = PrefabUtility.GetPrefabParent(selectGO);
		        if (prefabAsset != null) {
			        PrefabUtility.ReplacePrefab(selectGO, prefabAsset, ReplacePrefabOptions.ConnectToPrefab);
		        }
	        }
	        else {
				Debug.LogError("选中的实例不是Prefab实例！");
			}

			AssetDatabase.SaveAssets();

            // 代码缓存
            List<string> codes = new List<string>();

            // 设置lua文件名
            string filename = LUA_PATH + target.name + ".txt";
            LuaBehavior lua = binder.gameObject.GetComponent<LuaBehavior>();
            if (lua != null && string.IsNullOrEmpty(lua.filename) == false)
            {
                filename = LUA_PATH + lua.filename + ".txt";
            }

            // 文件已存在，将lua代码缓存
            if (File.Exists(filename))
            {
                StreamReader reader = new StreamReader(filename, System.Text.Encoding.UTF8);

                bool found = false;
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    if (line == COMPONENTS_END)
                    {
                        found = true;
                        continue;
                    }

                    // 已找到COMPONENTS_END注释，开始记录lua代码
                    if (found)
                        codes.Add(line);
                }

                // 没有找到Components注释段，重新读取整个文件并缓存
                if (found == false)
                {
                    reader.Close();
                    reader = new StreamReader(filename, System.Text.Encoding.UTF8);
                    while (!reader.EndOfStream)
                    {
                        codes.Add(reader.ReadLine());
                    }
                }

                reader.Close();
            }

            StreamWriter writer = new StreamWriter(filename, false, System.Text.Encoding.UTF8);

            // 写入Component注释段
            writer.WriteLine(COMPONENTS_START);
            foreach (ComponentBinder.Entry entry in entries)
            {
                if (entry.index == -1)
                    writer.WriteLine("--{0} {1}", entry.type, entry.key);
                else
                    writer.WriteLine("--{0} {1}[{2}]", entry.type, entry.key, entry.index);
            }
            writer.WriteLine(COMPONENTS_END);

            // 写入lua代码
            foreach (string code in codes)
            {
                writer.WriteLine(code);
            }

            writer.Close();
        }
    }
}
