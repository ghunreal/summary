﻿using UnityEngine;
using UnityEditor;
using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Collections.Generic;

public class MiniMap
{
    private string filePath = string.Empty;
    public Transform CameraTrans;
    static MiniMap()
    {

    }

    public void DrawGUI(EditorWindow wnd)
    {
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("EXPORT", EditorStyles.toolbarButton))
        {
            ExportMap();
        }
        GUILayout.EndHorizontal();
    }


    //返回顺序: minX, maxX, minY, maxY
    void InitExportParams(BlockParam block, out float[] arr, out int cType)
    {
        int len = 8;
        arr = new float[len];
        for (int i = 0; i < len; i++)
        {
            arr[i] = 0;
        }
        var c = block.GetComponent<Collider>();
        // 盒形碰撞体
        cType = 0;
        if (c is BoxCollider)
        {
            cType = 1;
            var box = (BoxCollider)c;
            var centerPt = c.transform.position;
            var lt = new Vector3(-0.5f * box.size.x * box.transform.localScale.x, 0.0f, +0.5f * box.size.z * box.transform.localScale.z);
            var lb = new Vector3(-0.5f * box.size.x * box.transform.localScale.x, 0.0f, -0.5f * box.size.z * box.transform.localScale.z);
            var rt = new Vector3(+0.5f * box.size.x * box.transform.localScale.x, 0.0f, +0.5f * box.size.z * box.transform.localScale.z);
            var rb = new Vector3(+0.5f * box.size.x * box.transform.localScale.x, 0.0f, -0.5f * box.size.z * box.transform.localScale.z);
            lt = box.transform.rotation * lt + centerPt;
            lb = box.transform.rotation * lb + centerPt;
            rt = box.transform.rotation * rt + centerPt;
            rb = box.transform.rotation * rb + centerPt;

            arr[0] = lt.x;
            arr[1] = lt.z;
            arr[2] = lb.x;
            arr[3] = lb.z;
            arr[4] = rb.x;
            arr[5] = rb.z;
            arr[6] = rt.x;
            arr[7] = rt.z;
        }
        // 圆形碰撞体
        else if (c is SphereCollider || c is CapsuleCollider)
        {
            cType = 2;
            Vector3 center;
            float radius = 0;
            if (c is SphereCollider)
            {
                center = (c as SphereCollider).center;
                radius = (c as SphereCollider).radius;
            }
            else
            {
                center = (c as CapsuleCollider).center;
                radius = (c as CapsuleCollider).radius;
            }
            arr[0] = center.x + c.transform.position.x;
            arr[1] = center.z + c.transform.position.z;
            arr[2] = radius;
        }
    }

    void ExportMap()
    {
        var go = new GameObject("TopCamera", typeof(Camera));
        var topCamera = go.GetComponent<Camera>();
        topCamera.orthographic = true;
        topCamera.transform.rotation = Quaternion.Euler(90, 0, 0.0f);
        
        topCamera.clearFlags = CameraClearFlags.SolidColor;
        topCamera.backgroundColor = Color.black;

        int waterLayerId = LayerMask.NameToLayer("Water");
        topCamera.cullingMask = ~(1 << waterLayerId);
        topCamera.farClipPlane = 100;

        var mapFilePath = EditorUtility.SaveFilePanel("Export MiniMap File", "", "", "png");
        if (string.IsNullOrEmpty(mapFilePath))
            return;
        try
        {
            float minX = 0;
            float minY = 0;
            float maxX = 0;
            float maxY = 0;
            float[] param = { 0, 0, 0, 0, 0, 0, 0, 0 };//左上x,左上y,左下x,左下y,右下x,右下y,右上x,右上y
            int cType = 0;          //碰撞体形状, 1矩形, 2圆形
            int iIndex = 0;

            var artGo = GameObject.Find(PROTOGONOS.Instance.gaia.ArtLevelName);
            foreach (var block in artGo.GetComponentsInChildren<BlockParam>())
            {
                var c = block.GetComponent<Collider>();
                if (c == null)
                    continue;

                iIndex = iIndex + 1;

                InitExportParams(block, out param, out cType);
                if (iIndex == 1)
                {
                    if (cType == 1)
                    {
                        minX = param[0] <= param[2] ? param[0] : param[2];
                        maxX = param[4] >= param[6] ? param[4] : param[6];
                        minY = param[1] <= param[3] ? param[1] : param[3];
                        maxY = param[5] >= param[7] ? param[5] : param[7];
                    }
                    else if (cType == 2)
                    {
                        minX = param[0] - param[2];
                        maxX = param[0] + param[2];
                        minY = param[1] - param[2];
                        maxY = param[1] + param[2];
                    }
                }
                else
                {
                    var tmpMinX = 0f;
                    var tmpMaxX = 0f;
                    var tmpMinY = 0f;
                    var tmpMaxY = 0f;
                    if (cType == 1)
                    {
                        tmpMinX = param[0] <= param[2] ? param[0] : param[2];
                        tmpMaxX = param[4] >= param[6] ? param[4] : param[6];
                        tmpMinY = param[1] <= param[3] ? param[1] : param[3];
                        tmpMaxY = param[5] >= param[7] ? param[5] : param[7];
                    }
                    else if (cType == 2)
                    {
                        tmpMinX = param[0] - param[2];
                        tmpMaxX = param[0] + param[2];
                        tmpMinY = param[1] - param[2];
                        tmpMaxY = param[1] + param[2];
                    }
                    minX = tmpMinX <= minX ? tmpMinX : minX;
                    maxX = tmpMaxX >= maxX ? tmpMaxX : maxX;
                    minY = tmpMinY <= minY ? tmpMinY : minY;
                    maxY = tmpMaxY >= maxY ? tmpMaxY : maxY;
                }
            }

            var designGo = GameObject.Find(PROTOGONOS.Instance.gaia.DesignLevelName);
            foreach (var block in designGo.GetComponentsInChildren<BlockParam>())
            {
                var c = block.GetComponent<Collider>();
                if (c == null)
                    continue;

                InitExportParams(block, out param, out cType);

                var tmpMinX = 0f;
                var tmpMaxX = 0f;
                var tmpMinY = 0f;
                var tmpMaxY = 0f;
                if (cType == 1)
                {
                    tmpMinX = param[0] <= param[2] ? param[0] : param[2];
                    tmpMaxX = param[4] >= param[6] ? param[4] : param[6];
                    tmpMinY = param[1] <= param[3] ? param[1] : param[3];
                    tmpMaxY = param[5] >= param[7] ? param[5] : param[7];
                }
                else if (cType == 2)
                {
                    tmpMinX = param[0] - param[2];
                    tmpMaxX = param[0] + param[2];
                    tmpMinY = param[1] - param[2];
                    tmpMaxY = param[1] + param[2];
                }
                minX = tmpMinX <= minX ? tmpMinX : minX;
                maxX = tmpMaxX >= maxX ? tmpMaxX : maxX;
                minY = tmpMinY <= minY ? tmpMinY : minY;
                maxY = tmpMaxY >= maxY ? tmpMaxY : maxY;
            }
            Debug.Log(string.Format("minX: {0}, maxX: {1}, minY: {2}, maxY: {3}", minX, maxX, minY, maxY));
            topCamera.transform.position = new Vector3(minX+(maxX-minX) / 2, 50, minY+(maxY - minY) / 2);
            topCamera.orthographicSize = (maxX - minX) / 2 + 10;

            CaptureCamera(topCamera, new Rect(0, 0, 1136, 640), mapFilePath);

        }
        catch (System.Exception ex)
        {
            EditorUtility.DisplayDialog("导出小地图错误", ex.Message, "确定");
        }
    }


    Texture2D CaptureCamera(Camera camera, Rect rect, string path)
    {
        // 创建一个RenderTexture对象  
        RenderTexture rt = new RenderTexture((int)rect.width, (int)rect.height, 0);
        rt.antiAliasing = 8;
        // 临时设置相关相机的targetTexture为rt, 并手动渲染相关相机  
        camera.targetTexture = rt;
        camera.Render();
        //ps: --- 如果这样加上第二个相机，可以实现只截图某几个指定的相机一起看到的图像。  
        //ps: camera2.targetTexture = rt;  
        //ps: camera2.Render();  
        //ps: -------------------------------------------------------------------  

        // 激活这个rt, 并从中中读取像素
        RenderTexture.active = rt;
        Texture2D screenShot = new Texture2D((int)rect.width, (int)rect.height, TextureFormat.ARGB32, false);
        screenShot.ReadPixels(rect, 0, 0);// 注：这个时候，它是从RenderTexture.active中读取像素  
        screenShot.Apply();

        // 重置相关参数，以使用camera继续在屏幕上显示  
        camera.targetTexture = null;
        //ps: camera2.targetTexture = null;  
        RenderTexture.active = null; // JC: added to avoid errors  
        GameObject.DestroyImmediate(rt);

        // 最后将这些纹理数据，成一个png图片文件  
        byte[] bytes = screenShot.EncodeToPNG();
        string filename = path;
        System.IO.File.WriteAllBytes(filename, bytes);
        Debug.Log(string.Format("截图保存至: {0}", filename));

        return screenShot;
    }

}