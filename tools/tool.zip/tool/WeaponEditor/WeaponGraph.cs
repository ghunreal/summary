﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEditor;
using System.Text.RegularExpressions;

[Serializable]
public class WeaponGraph : ScriptableObject
{
    public static readonly string EXPORT_LUA_PATH = "Assets/Scripts/Slua/Resources/weapon";
    public static readonly string EXPORT_CPP_PATH = "Assets/Editor Default Resources/Prometheus";

    public static readonly string PLATO_TEMPLATE_BASEPATH = "Assets/Editor Default Resources/PLATO/WeaponTemplate/";

	[SerializeField]
	public string assetName;

    public WeaponPhase weaponPhase = new WeaponPhase();
    private int _weaponID;
    private string filename;
	private Dictionary<string, string> typeKeyValue = new Dictionary<string, string>();

	public void Init()
	{
		if (!typeKeyValue.ContainsKey("System.String"))
			typeKeyValue.Add("System.String", "std::string");
		if (!typeKeyValue.ContainsKey("System.Int32"))
			typeKeyValue.Add("System.Int32", "int32_t");
		if (!typeKeyValue.ContainsKey("System.Single"))
			typeKeyValue.Add("System.Single", "float");
		if (!typeKeyValue.ContainsKey("System.Boolean"))
			typeKeyValue.Add("System.Boolean", "bool");

        weaponPhase.Load(_weaponID);
        isPreviewMacro = false;
        filename = string.Format("{0}/{1}{2}.txt", EXPORT_LUA_PATH, "WeaponScript", _weaponID);
	}

    private bool isPreviewMacro;

    /// <summary>
    /// 绘制编辑界面
    /// </summary>
    /// <param name="wnd"></param>
	public void UpdateGUI(EditorWindow wnd)
	{
        GUILayout.BeginHorizontal();
        EditorGUI.BeginDisabledGroup(isPreviewMacro);
        if (GUILayout.Button("Save", GUILayout.MaxWidth(100))) {
            //TODO Save Current Weapon
            weaponPhase.Save(_weaponID);
        }
        if (GUILayout.Button("Export", GUILayout.MaxWidth(100))) {
            //TODO Export Current Weapon

            weaponPhase.ExportLua(filename);
            // weaponPhase.ExportNode(_weaponID);
            // weaponPhase.ExportCpp(_weaponID);
            // weaponPhase.ExportComponentToCpp();
        }
        if (GUILayout.Button("Comment", GUILayout.MaxWidth(100)))
        {
            //skillPhaseList[skillIndex].Comment();
            weaponPhase.Comment();
        }
        EditorGUI.EndDisabledGroup();
        bool value = GUILayout.Toggle(isPreviewMacro, "预览宏展开");
        if (value != isPreviewMacro)
        {
            if (value)
            {
                weaponPhase.preview = new PLATO(weaponPhase.plato);
                PLATO.ExpandMacro(weaponPhase.preview);
            }
            else
            {
                weaponPhase.preview = null;
            }
        }
        isPreviewMacro = value;
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();

        //if (skillNames == null)
            //return;

        GUILayout.Label("Edit");

        //当前编辑武器的基础信息
        GUILayout.BeginHorizontal();
        GUILayout.Button("WeaponID", GUILayout.Width(80));
        GUILayout.Label(_weaponID.ToString(),GUILayout.Width(50));
        //GUILayout.Button("WeaponName", GUILayout.Width(100));
        //GUILayout.Label("武器" + _weaponID, GUILayout.Width(70));

        GUILayout.FlexibleSpace();
        if (GUILayout.Button("LoadTemplate", GUILayout.Width(150))) {
            //TODO Load Model Template
            if (!Directory.Exists(PLATO.PLATO_SAVE_PATH + "WeaponTemplate/"))
                Directory.CreateDirectory(PLATO.PLATO_SAVE_PATH + "WeaponTemplate/");

            string filename = EditorUtility.OpenFilePanel("Load Weapon Template File", PLATO.PLATO_SAVE_PATH + "WeaponTemplate/", "txt");
            Debug.Log("id = " + GetMidString(filename, PLATO_TEMPLATE_BASEPATH, ".txt"));
            weaponPhase.LoadTemplate(GetMidString(filename, PLATO_TEMPLATE_BASEPATH, ".txt"));
        }
        if (GUILayout.Button("SaveTemplate", GUILayout.Width(150))) {
            //TODO Save Model Template
            if (!Directory.Exists(PLATO.PLATO_SAVE_PATH + "WeaponTemplate/"))
                Directory.CreateDirectory(PLATO.PLATO_SAVE_PATH + "WeaponTemplate/");

            string filename = EditorUtility.SaveFilePanel("Save Weapon Template File", PLATO.PLATO_SAVE_PATH + "WeaponTemplate/", "WeaponTemplate1", "txt");
            Debug.Log("id = " + GetMidString(filename, PLATO_TEMPLATE_BASEPATH, ".txt"));
            weaponPhase.SaveTemplate(GetMidString(filename, PLATO_TEMPLATE_BASEPATH, ".txt"));
        }
        GUILayout.EndHorizontal();

        weaponPhase.UpdateGUI(wnd, 100);
	}

    public int WeaponID
    {
        set { _weaponID = value;}
        get { return _weaponID; }
    }


    public void ClearSkillData()
    {
        //skillData.Clear();
    }

    /// <summary>
    /// 正则表达式截取字符串 并转成Int
    /// </summary>
    /// <param name="defString"></param>
    /// <param name="start"></param>
    /// <param name="end"></param>
    /// <returns></returns>
    private int GetMidStringToInt(string defString, string start, string end)
    {
        int temp = 0;
        string str = "";
        try {
            Regex rg = new Regex("(?<=(" + start + "))[.\\s\\S]*?(?=(" + end + "))", RegexOptions.Multiline | RegexOptions.Singleline);
            str = rg.Match(defString).Value;
        }
        catch (Exception e) {
            str = "000";
        }

        try {
            temp = Convert.ToInt32(str);
        }
        catch {

        }


        return temp;
    }
    /// <summary>
    /// 正则表达式截取字符串 
    /// </summary>
    /// <param name="defString"></param>
    /// <param name="start"></param>
    /// <param name="end"></param>
    /// <returns></returns>
    private string GetMidString(string defString, string start, string end)
    {
        string str = "";
        try {
            Regex rg = new Regex("(?<=(" + start + "))[.\\s\\S]*?(?=(" + end + "))", RegexOptions.Multiline | RegexOptions.Singleline);
            str = rg.Match(defString).Value;
        }
        catch (Exception e) {
            str = "0";
        }

        return str;
    }
}










