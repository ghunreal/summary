﻿using UnityEngine;
using System.IO;
using System.Security.Cryptography;


/// <summary>
/// 数据加密
/// </summary>
public static class DataEncryptor {
    private static string D = "ENUUhL1rrzLisexldw3OkJ6wOlcqz6FSAVZSJMj9sBFChW8yxdDbaYcJlgHUDb++8WjmxDh4VxzvRX+BgxKOnTV0bfQrSsQYjV7CkaNjdCCKLoNWmC64Zrw5KhdMOrRs5MOASy4rJFOaID9ig7wc5teB5dkaCG+P93Ppqaz/S8k=";
    private static string N = "jxMuaEoTUTCG6Flec/VbzUTZ7+Tr5Ns5C126OKxsWJK1bjEvkW9JAPvRew+KdN3XA/upg9/+5HXxzrvM2h28OcWaGS2J87nnOX1Kkpb9kVk5QuYmQCIfCMExM4SnfCtbi3L6vQMpeN2truAYTA4MQHH/cMFUkTCRlGQFfnlyYyU=";
    private static BigInteger d;
    private static BigInteger n;

    /// <summary>
    /// 创建D和N的大整数表示
    /// </summary>
    static DataEncryptor()
    {
        d = new BigInteger(System.Convert.FromBase64String(D));
        n = new BigInteger(System.Convert.FromBase64String(N));
    }

    /// <summary>
    /// 打开文件读取所有字节后加密
    /// </summary>
    /// <param name="filename"></param>
    public static void Encrypt(string filename)
    {
        StreamReader reader = new StreamReader(filename, System.Text.Encoding.UTF8);
        byte[] data = System.Text.Encoding.UTF8.GetBytes(reader.ReadToEnd());
        reader.Close();

        // 有几率校验失败，重新加密直到成功
        byte[] result = null;
        do
        {
            result = EncryptData(data, d, n);
        } while (!CSVReader.Validate(result, data));

        // 保存为.bytes文件
        using (FileStream stream = new FileStream(Path.ChangeExtension(filename, ".bytes"), FileMode.Create, FileAccess.Write))
        {
            stream.Write(result, 0, result.Length);
            stream.Flush();
            stream.Close();
        }
    }

    /// <summary>
    /// 使用AES加密字节数据，使用RSA加密AES KEY
    /// </summary>
    /// <param name="input"></param>
    /// <param name="d"></param>
    /// <param name="n"></param>
    /// <returns></returns>
    static byte[] EncryptData(byte[] input, BigInteger d, BigInteger n)
    {
        RijndaelManaged aes = new RijndaelManaged();
        aes.KeySize = 128;
        aes.BlockSize = 128;
        aes.Mode = CipherMode.CBC;
        aes.Padding = PaddingMode.PKCS7;
        aes.GenerateKey();
        aes.GenerateIV();

        ICryptoTransform ct = aes.CreateEncryptor(aes.Key, aes.IV);
        byte[] encrypt = ct.TransformFinalBlock(input, 0, input.Length);

        // Encrypt the AES Key with RSA
        byte[] keyex = EncryptKeyExchange(aes.Key, d, n);

        // 文件结构
        // 加密的AES KEY：128位
        // 明文AES IV：16位
        // 使用AES KEY加密的数据
        byte[] result = new byte[keyex.Length + aes.IV.Length + encrypt.Length];
        System.Buffer.BlockCopy(keyex, 0, result, 0, keyex.Length);
        System.Buffer.BlockCopy(aes.IV, 0, result, keyex.Length, aes.IV.Length);
        System.Buffer.BlockCopy(encrypt, 0, result, keyex.Length + aes.IV.Length, encrypt.Length);
        return result;
    }

    /// <summary>
    /// 加密交换码
    /// </summary>
    /// <param name="key"></param>
    /// <param name="d"></param>
    /// <param name="n"></param>
    /// <returns></returns>
    static byte[] EncryptKeyExchange(byte[] key, BigInteger d, BigInteger n)
    {
        BigInteger bi = new BigInteger(key);
        return bi.modPow(d, n).getBytes();
    }
}
