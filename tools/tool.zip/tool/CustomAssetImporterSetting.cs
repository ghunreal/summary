﻿using UnityEngine;
using UnityEditor;

public class CustomAssetImporterSetting : EditorWindow
{
    public static TextureImporterType textureType = TextureImporterType.Advanced;
    [MenuItem("Custom/Importer Setting")]
    public static void OpenWindow()
    {
        EditorWindow.GetWindow<CustomAssetImporterSetting>();
    }

    void OnGUI()
    {
        GUILayout.Label("Texture setting", EditorStyles.boldLabel);
        textureType = (TextureImporterType)EditorGUILayout.EnumPopup("Import type", textureType);
    }
}
