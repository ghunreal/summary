﻿using UnityEngine;
using System.Collections.Generic;
using System;
using System.IO;
using UnityEditor.Animations;
using UnityEditor;

namespace Assets.Editor.AnimatorEditor
{
    public class AETemplate
    {
        private Vector2 scrollPosition;

        public List<AELayer> Layers = new List<AELayer>();
        public List<AEParameter> Parameters = new List<AEParameter>();

        public void Draw(EditorWindow wnd)
        {
            Color oldColor = GUI.color;
            GUI.color = AEConfig.TEMPLATE_COLOR;

            EditorGUILayout.BeginVertical();
            scrollPosition = GUI.BeginScrollView(
                  new Rect() { x = 0f, y = AEConfig.SCROLL_HEIGHT_OFFSET, width = wnd.position.width, height = wnd.position.height - AEConfig.SCROLL_HEIGHT_OFFSET },
                  scrollPosition,
                  new Rect(0, AEConfig.SCROLL_HEIGHT_OFFSET - 20f, AEConfig.SCROLL_WIDTH, AEConfig.SCROLL_HEIGHT),
                  true,
                  true);
            EditorGUILayout.BeginVertical("window");
            EditorGUILayout.LabelField("Animator");
            DrawParameters();
            EditorGUILayout.Space();
            DrawLayers();
            EditorGUILayout.Space();

            EditorGUILayout.EndVertical();
            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();

            GUI.color = oldColor;
        }

        public void Save(string fileName)
        {

            string content = String.Empty;
            string tableName = Path.GetFileNameWithoutExtension(fileName);
            content += "local " + tableName + " = {\n";

            content += "\t";
            content += "Parameters = {\n";
            for (int i = 0;i < Parameters.Count;i++)
            {
                Parameters[i].ExportToLua(ref content);
            }
            content += "\t";
            content += "},\n";// Parameters End

            content += "\t";
            content += "Layers = {\n";
            for (int i = 0;i < Layers.Count;i++)
            {
                Layers[i].ExportToLua(ref content);
            }
            content += "\t";
            content += "},\n";// Layers End

            content += "}";//Table End
            content += "\n\n";

            content += "\nreturn " + tableName;
            bool ret = FileWriterProxy.Write(fileName, content);
            if (ret)
            {
                AEUtil.ShowNotification("Save Success");
            }
        }

        public void SaveInstance(PTCharacterType type, string index)
        {
            string content = String.Empty;
            string tableName = type + index + "Animator";
            content += "local " + tableName + " = {\n";

            content += "\t";
            content += "Parameters = {\n";
            for (int i = 0;i < Parameters.Count;i++)
            {
                Parameters[i].ExportToLua(ref content);
            }
            content += "\t";
            content += "},\n";// Parameters End

            content += "\t";
            content += "Layers = {\n";
            for (int i = 0;i < Layers.Count;i++)
            {
                Layers[i].ExportToLua(ref content);
            }
            content += "\t";
            content += "},\n";// Layers End

            content += "}";//Table End
            content += "\n\n";

            content += "\nreturn " + tableName;
            bool ret = FileWriterProxy.Write(string.Format("{0}{1}.txt", AEConfig.ANIMATOR_INSTANCE_PATH, tableName), content);
            if (ret)
            {
                AEUtil.ShowNotification("Save Success");
            }
        }

        private string curCharacterName;
        private string animBasePath;
        private string prefabName;
        private string controllerSavePath;
        private AnimatorController productController;
        public void Export(PTCharacterType type, string index)
        {
            switch (type)
            {
                case PTCharacterType.Hero:
                    curCharacterName = string.Format("Hero{0}", index);
                    animBasePath = Path.Combine(AEConfig.HERO_ANIM_ROOT_PATH, string.Format("{0}/Hero{1}@{2}", index, index, index));
                    controllerSavePath = AEConfig.HERO_CONTROLLER_BASE_PATH + "AutoAnimCtrl_" + curCharacterName + ".controller";
                    break;
                case PTCharacterType.Npc:
                    curCharacterName = string.Format("Npc{0}", index);
                    animBasePath = Path.Combine(AEConfig.NPC_ANIM_ROOT_PATH, string.Format("{0}/Npc{1}@{2}", index, index, index));
                    controllerSavePath = AEConfig.NPC_CONTROLLER_BASE_PATH + "AutoAnimCtrl_" + curCharacterName + ".controller";
                    break;
                default:
                    return;
            }
            prefabName = AEUtil.GetCharacterPrefabName(index, type);
            Debug.Log("CreateController to " + curCharacterName);

            productController = GetControllerByPath(controllerSavePath);
            AEUtil.BindControllerToPrefab(prefabName, productController);
        }

        private void DrawParameters()
        {
            Color oldColor = GUI.color;
            GUI.color = AEConfig.PARAMETER_COLOR;

            EditorGUILayout.BeginVertical("window");
            EditorGUILayout.LabelField("Parameters");
            for (int i = 0;i < Parameters.Count;i++)
            {
                Parameters[i].Draw();
            }
            EditorGUILayout.Space();
            EditorGUILayout.EndVertical();

            GUI.color = oldColor;
        }

        private void DrawLayers()
        {
            Color oldColor = GUI.color;
            GUI.color = AEConfig.LAYER_COLOR;

            EditorGUILayout.BeginVertical("window");
            EditorGUILayout.LabelField("Layers");
            for (int i = 0;i < Layers.Count;i++)
            {
                Layers[i].Draw();
                EditorGUILayout.Space();
            }
            EditorGUILayout.EndVertical();

            GUI.color = oldColor;
        }

        private AnimatorController GetControllerByPath(string savePath)
        {
            AnimatorController result = (AnimatorController)AssetDatabase.LoadAssetAtPath(savePath, typeof(AnimatorController));
            if (result == null)
            {
                result = AnimatorController.CreateAnimatorControllerAtPath(controllerSavePath);
                if (null == result)
                {
                    AEUtil.ShowNotification(string.Format("Can't create controller file, path = {0}", savePath));
                }
            }else{
                // 删除不包含Skill的状态
                AEUtil.RemoveStatesByName(result, "Skill", false);
            }

            AddParameters(result);

            AddLayers(result);
            return result;
        }

        private void AddParameters(AnimatorController controller)
        {
            if (controller == null)
                return;

            for (int i = 0;i < Parameters.Count;i++)
            {
                if(AEUtil.HasParameter(controller, Parameters[i].ParameterName))
                    continue;
                AnimatorControllerParameter parameter = new AnimatorControllerParameter();
                parameter.name = Parameters[i].ParameterName;
                parameter.type = Parameters[i].ParameterType;
                switch (parameter.type)
                {
                    case AnimatorControllerParameterType.Float:
                        parameter.defaultFloat = Convert.ToSingle(Parameters[i].DefaultValue);
                        break;
                    case AnimatorControllerParameterType.Int:
                        parameter.defaultInt = Convert.ToInt32(Parameters[i].DefaultValue);
                        break;
                    case AnimatorControllerParameterType.Bool:
                        parameter.defaultBool = Convert.ToBoolean(Parameters[i].DefaultValue);
                        break;
                    case AnimatorControllerParameterType.Trigger:
                        break;
                    default:
                        break;
                }

                controller.AddParameter(parameter);
            }
        }

        private void AddLayers(AnimatorController controller)
        {
            if (controller == null)
                return;

            for (int i = 0;i < Layers.Count;i++)
            {
                if (i != 0 && !AEUtil.HasLayer(controller, Layers[i].LayerName))
                    controller.AddLayer(Layers[i].LayerName);
                Layers[i].Build(controller.layers[i].stateMachine, animBasePath, controller);
            }

            // 如果不止一层则设置高层的权重为1
            if (controller.layers.Length > 1)
            {
                AnimatorControllerLayer[] layers = controller.layers;
                layers[1].defaultWeight = 1f;
                layers[1].blendingMode = AnimatorLayerBlendingMode.Override;
                controller.layers = layers;
            }
        }
    }
}
