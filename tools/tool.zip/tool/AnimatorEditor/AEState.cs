﻿using UnityEngine;
using UnityEditor.Animations;
using UnityEditor;

namespace Assets.Editor.AnimatorEditor
{
    public class AEState
    {
        public string StateName = string.Empty;
        public string Suffix = string.Empty;
        public float Speed { get; set; }
        public string SpeedParameter = string.Empty;
        public string BehaviorName = string.Empty;

        public void Draw()
        {
            EditorGUILayout.BeginVertical();
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("StateName:", GUILayout.Width(AEConfig.LABEL_COLUMN_WIDTH));
            StateName = EditorGUILayout.TextField(StateName, GUILayout.Width(AEConfig.TEXT_COLUMN_WIDTH));
            EditorGUILayout.LabelField("AnimSuffix:", GUILayout.Width(AEConfig.LABEL_COLUMN_WIDTH));
            Suffix = EditorGUILayout.TextField(Suffix, GUILayout.Width(AEConfig.TEXT_COLUMN_WIDTH));
            EditorGUILayout.LabelField("Speed:", GUILayout.Width(AEConfig.LABEL_COLUMN_WIDTH));
            Speed = EditorGUILayout.FloatField(Speed, GUILayout.Width(AEConfig.FLOAT_COLUMN_WIDTH));
            EditorGUILayout.LabelField("SpeedParameter:", GUILayout.Width(AEConfig.LABEL_COLUMN_WIDTH));
            SpeedParameter = EditorGUILayout.TextField(SpeedParameter, GUILayout.Width(AEConfig.TEXT_COLUMN_WIDTH));
            EditorGUILayout.LabelField("BehaviorName:", GUILayout.Width(AEConfig.LABEL_COLUMN_WIDTH));
            BehaviorName = EditorGUILayout.TextField(BehaviorName, GUILayout.Width(AEConfig.TEXT_COLUMN_WIDTH));
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.EndVertical();
        }

        public AnimatorState Build(AnimatorStateMachine machine, string animBasePath)
        {
            // Load Animation
            AnimationClip clip = AEUtil.LoadAnimClip(string.Format("{0}_{1}.FBX", animBasePath, Suffix));

            // add tree state & set state motion
            AnimatorState state = machine.AddState(StateName);
            state.motion = clip;

            if (Speed > 0f)
                state.speed = Speed;

            if (!string.IsNullOrEmpty(SpeedParameter))
            {
                state.speedParameterActive = true;
                state.speedParameter = SpeedParameter;
            }

            // add LuaStateMachineBehavior
            if (!string.IsNullOrEmpty(BehaviorName))
            {
                var luaSmb = state.AddStateMachineBehaviour<LuaStateMachineBehavior>();
                luaSmb.filename = BehaviorName;
                luaSmb.curState = StateName;
            }
            
            return state;
        }

        public void ExportToLua(ref string content)
        {
            content += "\t\t\t\t{ ";

            content += "StateName = \"" + StateName + "\", ";
            if (!string.IsNullOrEmpty(Suffix))
                content += "Suffix = \"" + Suffix + "\", ";
            if (Speed > 0f)
                content += "Speed = " + Speed + ", ";
            if (!string.IsNullOrEmpty(SpeedParameter))
                content += "SpeedParameter = \"" + SpeedParameter + "\", ";
            if (!string.IsNullOrEmpty(BehaviorName))
                content += "BehaviorName = \"" + BehaviorName + "\", ";

            content += "},\n";// State End
        }
    }
}