﻿using System.Collections.Generic;
using UnityEditor.Animations;
using UnityEditor;
using UnityEngine;

namespace Assets.Editor.AnimatorEditor
{
    public class AELayer
    {
        private Dictionary<string, AnimatorState> statesMap = new Dictionary<string, AnimatorState>();
        public string LayerName { get; set; }
        
        public List<AEState> States = new List<AEState>();
        public List<AEBlendTree> Trees = new List<AEBlendTree>();
        public List<AETransition> Transitions = new List<AETransition>();

        public void Draw()
        {
            EditorGUILayout.BeginVertical();
            EditorGUILayout.BeginVertical("window");
            EditorGUILayout.LabelField("LayerName: " + LayerName);

            DrawStates();
            EditorGUILayout.Space();

            DrawTrees();
            EditorGUILayout.Space();

            DrawTransitions();
            EditorGUILayout.Space();


            EditorGUILayout.EndVertical();
        }

        private void DrawStates()
        {
            Color oldColor = GUI.color;
            GUI.color = AEConfig.STATE_COLOR;
            
            EditorGUILayout.BeginVertical("box");
            EditorGUILayout.LabelField("States");
            for (int i = 0; i < States.Count; i++)
            {
                States[i].Draw();
            }
            EditorGUILayout.EndVertical();

            GUI.color = oldColor;
        }

        private void DrawTrees()
        {
            EditorGUILayout.BeginVertical("box");
            EditorGUILayout.LabelField("BlendTrees");
            for (int i = 0; i < Trees.Count; i++)
            {
                Trees[i].Draw();
            }
            EditorGUILayout.EndVertical();
        }

        private void DrawTransitions()
        {
            EditorGUILayout.BeginVertical("window");
            EditorGUILayout.LabelField("Transitions");
            for (int i = 0; i < Transitions.Count; i++)
            {
                Transitions[i].Draw();
                EditorGUILayout.Space();
            }
            EditorGUILayout.EndVertical();
        }

        public void Build(AnimatorStateMachine machine, string animBasePath, AnimatorController productController)
        {
            statesMap.Clear();
            AddStates(machine, animBasePath);
            AddBlendTrees(machine, animBasePath, productController);
            AddTransition(machine);
        }

        public void ExportToLua(ref string content)
        {
            content += "\t\t{\n";

            content += "\t\t\tLayerName = \"" + LayerName + "\",\n";

            content += "\t\t\tStates = {\n";
            for (int i = 0; i < States.Count; i++)
            {
                States[i].ExportToLua(ref content);
            }
            content += "\t\t\t},\n";// States End

            if(Trees.Count > 0)
            {
                content += "\t\t\tBlendTrees = {\n";
                for (int i = 0; i < Trees.Count; i++)
                {
                    Trees[i].ExportToLua(ref content);
                }
                content += "\t\t\t},\n";// Trees End
            }

            content += "\t\t\tTransitions = {\n";
            for (int i = 0; i < Transitions.Count; i++)
            {
                Transitions[i].ExportToLua(ref content);
            }
            content += "\t\t\t},\n";// States End

            content += "\t\t},\n";// Layer End
        }

        private void AddBlendTrees(AnimatorStateMachine machine, string animBasePath, AnimatorController productController)
        {
            for (int i = 0; i < Trees.Count; i++)
            {
                AnimatorState state = Trees[i].Build(machine, animBasePath, productController);
                AddStateToMap(Trees[i].StateName, state);
            }
        }

        private void AddStates(AnimatorStateMachine machine, string animBasePath)
        {
            for (int i = 0; i < States.Count; i++)
            {
                AnimatorState state = States[i].Build(machine, animBasePath);
                AddStateToMap(States[i].StateName, state);
            }
        }

        private void AddStateToMap(string name, AnimatorState state)
        {
            if(state == null)
            {
                AEUtil.ShowNotification(string.Format("State is null {0}", name));
                return;
            }
            if (statesMap.ContainsKey(name))
            {
                AEUtil.ShowNotification(string.Format("There is a same name state already {0}", name));
                return;
            }
            statesMap.Add(name, state);
        }

        private void AddCondition(AnimatorStateTransition animatorTransition, AETransition transition)
        {
            if (animatorTransition == null)
                return;
            foreach (var item in transition.Conditions)
            {
                if (string.IsNullOrEmpty(item.ParameterName))
                    continue;
                animatorTransition.AddCondition(item.ConditionMode, item.Threshold, item.ParameterName);
            }
        }

        private void AddTransition(AnimatorStateMachine machine)
        {
            AnimatorState fromState;
            AnimatorState toState;
            
            for (int i = 0; i < Transitions.Count; i++)
            {
                AnimatorStateTransition tempTrans = null;
                switch (Transitions[i].Type)
                {
                    case TransitionType.Normal:
                        if (statesMap.TryGetValue(Transitions[i].FromStateName, out fromState))
                        {
                            if (statesMap.TryGetValue(Transitions[i].ToStateName, out toState))
                            {
                                tempTrans = fromState.AddTransition(toState);
                                AddCondition(tempTrans, Transitions[i]);
                            }
                            else
                            {
                                AEUtil.ShowNotification(string.Format("Can't Find To State {0}", Transitions[i].ToStateName));
                                break;
                            }
                        }
                        else
                            AEUtil.ShowNotification(string.Format("Can't Find From State {0}", Transitions[i].FromStateName));
                        break;
                    case TransitionType.Entry:
                        if (statesMap.TryGetValue(Transitions[i].ToStateName, out toState))
                            machine.defaultState = toState;
                        else
                            AEUtil.ShowNotification(string.Format("Can't Find Entry State {0}", Transitions[i].ToStateName));
                        break;
                    case TransitionType.Exit:
                        if (statesMap.TryGetValue(Transitions[i].FromStateName, out fromState))
                        {
                            tempTrans = fromState.AddExitTransition();
                            AddCondition(tempTrans, Transitions[i]);
                        }
                        else
                            AEUtil.ShowNotification(string.Format("Can't Find To Exit State {0}", Transitions[i].ToStateName));
                        break;
                    case TransitionType.AnyState:
                        if (statesMap.TryGetValue(Transitions[i].ToStateName, out toState))
                        {
                            tempTrans = machine.AddAnyStateTransition(toState);
                            AddCondition(tempTrans, Transitions[i]);
                        }
                        else
                            AEUtil.ShowNotification(string.Format("Can't Find Any To State {0}", Transitions[i].ToStateName));
                        break;
                    case TransitionType.All:
                        if (statesMap.TryGetValue(Transitions[i].ToStateName, out toState))
                        {
                            var enumState = statesMap.GetEnumerator();
                            while (enumState.MoveNext())
                            {
                                if (enumState.Current.Key != Transitions[i].ToStateName)
                                {
                                    tempTrans = enumState.Current.Value.AddTransition(toState);
                                    AddCondition(tempTrans, Transitions[i]);
                                }
                            }
                        }
                        else
                            AEUtil.ShowNotification(string.Format("Can't Find From All To State {0}", Transitions[i].ToStateName));
                        break;
                    default:
                        break;
                }
                if(tempTrans != null)
                {
                    tempTrans.duration = 0f;
                    tempTrans.interruptionSource = TransitionInterruptionSource.Source;
                    tempTrans.canTransitionToSelf = Transitions[i].CanTransitionToSelf;

                    if(Transitions[i].ExitTime > 0f)
                    {
                        tempTrans.hasExitTime = true;
                        tempTrans.exitTime = Transitions[i].ExitTime;
                    }

                    if (Transitions[i].Duration > 0f)
                    {
                        tempTrans.duration = Transitions[i].Duration;
                    }
                    if (Transitions[i].Offset > 0f)
                    {
                        tempTrans.offset = Transitions[i].Offset;
                    }
                }
                
            }
        }
    }
}