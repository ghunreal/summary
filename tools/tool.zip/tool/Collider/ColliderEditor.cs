﻿using UnityEngine;
using UnityEditor;
using System.Collections;

public class ColliderEditor : EditorWindow {

    static void SetNavMeshData(GameObject go, Collider collider)
    {
        if (collider == null || !(collider as BoxCollider || collider as CapsuleCollider))
            return;

        NavMeshObstacle nm = go.GetComponent<NavMeshObstacle>();
        if (nm == null)
        {
            nm = go.AddComponent<NavMeshObstacle>();
        }

        if (collider as BoxCollider)
        {
            nm.shape = NavMeshObstacleShape.Box;
            nm.center = ((BoxCollider)collider).center;
            nm.size = ((BoxCollider)collider).size;
        }
        else
        {
            nm.shape = NavMeshObstacleShape.Capsule;
            nm.center = ((CapsuleCollider)collider).center;
            nm.radius = ((CapsuleCollider)collider).radius;
            nm.height = ((CapsuleCollider)collider).height;
        }

    }

    static void CheckCollider(GameObject go)
    {
        Collider collider = go.GetComponent<Collider>();
        if (collider != null)
        {
            SetNavMeshData(go, collider);
        }

        for(int i = 0; i < go.transform.childCount; ++ i)
        {
            CheckCollider(go.transform.GetChild(i).gameObject);
        }

    }

    [MenuItem("Utility/Collider/Export Collider to NavMesh")]
    public static void OnExportToNavMesh()
    {
        GameObject[] select = Selection.gameObjects;
        if(select.Length == 0)
        {
            return;
        }

        foreach( var go in select)
        {
            CheckCollider(go);
        }

    }

    [MenuItem("Utility/Collider/Optimization of Capsule Collider")]
    public static void OnOptimizationCapsule()
    {
        GameObject[] select = Selection.gameObjects;
        if (select.Length == 0)
        {
            return;
        }

        foreach (var go in select)
        {
            CheckCapsule(go);
        }
    }

    static void CheckCapsule(GameObject go)
    {
        CapsuleCollider collider = go.GetComponent<CapsuleCollider>();
        if (collider != null)
        {
            OptimizationCapsule(collider);
        }

        for (int i = 0; i < go.transform.childCount; ++i)
        {
            CheckCapsule(go.transform.GetChild(i).gameObject);
        }
    }

    static void OptimizationCapsule(CapsuleCollider collider)
    {
        if (collider == null)
            return;

        collider.height = collider.height + 2 * collider.radius;
    }

}
